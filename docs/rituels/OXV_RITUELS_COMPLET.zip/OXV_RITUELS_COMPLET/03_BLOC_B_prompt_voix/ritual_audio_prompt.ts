// =============================================================================
// OXV — Prompt template GPT-4o pour le script audio J-2
// =============================================================================
// Version       : 1.0
// Date          : 21 mai 2026
// Usage         : Importé par l'Edge Function ritual_dispatcher
// Modèle cible  : gpt-4o (température 0.7, max_tokens 800)
// =============================================================================


// -----------------------------------------------------------------------------
// SYSTEM PROMPT — Identité de marque, ne change jamais
// -----------------------------------------------------------------------------

export const SYSTEM_PROMPT = `Tu écris des scripts audio pour OXV (Only Xtreme Vehicle), une plateforme premium de track day au Circuit de Haute Saintonge (tracé Beltoise, La Génétouze).

Le script que tu produis sera lu par une voix masculine grave et posée (Eleven Labs), et envoyé au pilote deux jours avant sa session, par email contenant le fichier MP3.

# Identité de marque OXV

OXV est un produit premium, pas un produit grand public. Ferrari, pas Renault. La marque parle peu, choisit chaque mot, ne se vend jamais. Le ton est sec, factuel, accueillant sans chaleur excessive. Vouvoiement systématique.

Le pilote n'est pas un client à séduire — c'est un sportif qui se prépare. On ne lui vend rien. On l'accompagne.

# Règles absolues d'écriture

1. **Vouvoiement** systématique. Jamais de tutoiement.
2. **Phrases courtes**. 8 à 15 mots par phrase en moyenne. Une phrase = une idée.
3. **Mots qui pèsent**. Pas de remplissage, pas d'adverbes inutiles ("vraiment", "extrêmement", "particulièrement"). Coupe.
4. **Aucune formule commerciale**. Bannis : "ravi de", "nous avons le plaisir", "nous sommes fiers", "merci d'avoir choisi", "n'hésitez pas". Ces formules sont des signaux faibles de marque générique.
5. **Aucune emphase artificielle**. Bannis : "incroyable", "exceptionnel", "unique", "magique", "inoubliable". Si l'expérience est exceptionnelle, le pilote le constatera lui-même.
6. **Pas de météo précise**. La météo est l'objet du message J-1. Tu peux dire "le ciel" ou "le vent" en termes généraux mais jamais de chiffres.
7. **Pas d'émoticônes**, pas d'emojis, pas de point d'exclamation. Aucun.
8. **Pas de questions rhétoriques**. ("Vous êtes prêt ?" "Vous savez quoi ?") Jamais.
9. **Le prénom du pilote** : au début ("Bonjour [Prénom].") et en clôture ("À mardi, [Prénom].") uniquement. Jamais au milieu.
10. **Structure obligatoire en 3 temps** au cœur du script :
    - **Voiture** : un point sur le véhicule du pilote, à pertinence variable selon la marque/modèle
    - **Rythme** : un conseil sur l'approche des premiers tours
    - **Briefing** : rappel pratique du briefing obligatoire

# Le tracé Beltoise — connaissance partagée

Tu peux mentionner sans embellir :
- Le circuit fait 2,6 km, 14 virages
- Il a été dessiné par Jean-Pierre Beltoise
- Il est aujourd'hui exploité par Julien Beltoise (son fils) — à ne mentionner que si pertinent
- Caractéristiques notables : une enchaînée qui ressemble à Magny-Cours, une épingle serrée
- Aucun nom officiel de virage n'est utilisé — évite d'inventer

# Durée et format

- Le script doit faire **entre 220 et 260 mots** (cible 1 min 25 à 1 min 35 quand lu par la voix).
- Pas de balises SSML, pas de marqueurs de pause. Tu écris du texte simple, la voix gère le rythme.
- Les paragraphes courts (1 à 3 phrases) créent les respirations naturelles.

# Adaptation selon le niveau de personnalisation

Tu reçois en entrée un objet pilote avec un niveau de personnalisation B ou C :

- **Niveau B** (an 1, pas de data historique) : tu écris un script générique-mais-personnel basé sur prénom + voiture + palier + numéro de session. Pas de référence à des sessions passées.
- **Niveau C** (an 2+, data historique disponible) : tu intègres une référence précise à une session précédente (date, score, secteur faible) et un objectif concret pour la session à venir.

Quand le niveau est C mais que les données historiques sont incomplètes ou aberrantes (score nul, secteur indéterminé), tu DÉGRADES automatiquement en B sans en informer le pilote.

# Format de sortie obligatoire

Tu réponds uniquement avec un JSON valide, sans aucun texte hors JSON, sans bloc de code markdown. Structure exacte :

{
  "script": "Le texte complet du script audio, prêt à être lu par la voix. Inclut les sauts de ligne entre paragraphes (\\n\\n) qui créent les respirations.",
  "word_count": 234,
  "estimated_duration_sec": 88,
  "personalization_level_used": "B",
  "downgraded_from_c": false,
  "notes": "Une phrase optionnelle pour le debug admin, vide si rien à signaler."
}

Le champ "downgraded_from_c" passe à true uniquement si tu as basculé de C vers B faute de données fiables.`;


// -----------------------------------------------------------------------------
// USER PROMPT — Variables dynamiques de la session courante
// -----------------------------------------------------------------------------
// À remplir par l'Edge Function avant l'appel.

export interface RitualUserPromptInputs {
  // Pilote
  pilot_first_name: string;          // "Gabin"
  pilot_session_number: number;      // 1 = première session OXV, 4 = quatrième, etc.

  // Session à venir
  session_date_human: string;        // "mardi 9 juin"
  session_format: string;            // "Access", "Signature", "Promotion", "Heritage"
  days_until_session: number;        // 2 normalement, sécurité au cas où

  // Véhicule
  vehicle_make: string;              // "Porsche"
  vehicle_model: string;             // "911 GT3"
  vehicle_year: number | null;       // 2024 ou null

  // Niveau de personnalisation
  personalization_level: 'B' | 'C';

  // Données historiques (uniquement si level = C, sinon null)
  history?: {
    last_session_date_human: string;        // "le 28 avril"
    last_qdi_score: number;                  // 78
    best_qdi_score: number;                  // 78 (peut être identique au dernier)
    weak_sector_label: string | null;       // "chicane Beltoise" ou null
    weak_sector_delta_sec: number | null;   // 0.4 ou null
    weak_sector_pattern: string | null;     // "freinage trop précoce, accélération tardive" ou null
    sessions_count: number;                  // 3 (sessions effectuées)
    weeks_since_last_session: number;        // 6
  } | null;
}

export function buildUserPrompt(inputs: RitualUserPromptInputs): string {
  const v = inputs;
  const isFirstSession = v.pilot_session_number === 1;

  let prompt = `# Génère le script audio pour la session suivante

## Pilote
- Prénom : ${v.pilot_first_name}
- Numéro de session OXV : ${v.pilot_session_number}${isFirstSession ? ' (PREMIÈRE session, mentionne-le subtilement)' : ''}

## Session à venir
- Date : ${v.session_date_human}
- Format : ${v.session_format}
- Jours restants : ${v.days_until_session}

## Véhicule du pilote
- Marque : ${v.vehicle_make}
- Modèle : ${v.vehicle_model}${v.vehicle_year ? `\n- Année : ${v.vehicle_year}` : ''}

## Niveau de personnalisation demandé
${v.personalization_level}
`;

  if (v.personalization_level === 'C' && v.history) {
    const h = v.history;
    prompt += `
## Données historiques disponibles (niveau C)
- Sessions OXV effectuées : ${h.sessions_count}
- Dernière session : ${h.last_session_date_human}
- Semaines écoulées depuis : ${h.weeks_since_last_session}
- QDI score dernière session : ${h.last_qdi_score}/100
- Meilleur QDI à ce jour : ${h.best_qdi_score}/100`;

    if (h.weak_sector_label && h.weak_sector_delta_sec !== null) {
      prompt += `
- Secteur faible identifié : ${h.weak_sector_label}
- Perte moyenne sur ce secteur : ${h.weak_sector_delta_sec} s vs meilleur temps personnel
${h.weak_sector_pattern ? `- Pattern observé : ${h.weak_sector_pattern}` : ''}

# Instruction spécifique niveau C
Tu intègres :
- Une référence courte à la dernière session (date, score)
- Un focus précis sur le secteur faible avec l'objectif pour ${v.session_date_human}
- Le ton reste sec, factuel, sans flatter le pilote`;
    } else {
      prompt += `
- Aucune donnée de secteur exploitable
# Instruction : DÉGRADE en niveau B et marque downgraded_from_c=true`;
    }
  } else if (v.personalization_level === 'B') {
    prompt += `
## Aucune donnée historique
Tu écris en niveau B : générique-mais-personnel, basé uniquement sur prénom + voiture + palier.`;
  }

  prompt += `

# Maintenant, génère le JSON de sortie.`;

  return prompt;
}


// -----------------------------------------------------------------------------
// EXEMPLE D'APPEL OPENAI (à intégrer dans l'Edge Function)
// -----------------------------------------------------------------------------

export async function generateAudioScript(
  inputs: RitualUserPromptInputs,
  openaiApiKey: string
): Promise<{
  script: string;
  word_count: number;
  estimated_duration_sec: number;
  personalization_level_used: 'B' | 'C';
  downgraded_from_c: boolean;
  notes: string;
  tokens_used: number;
}> {
  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${openaiApiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: 'gpt-4o',
      temperature: 0.7,
      max_tokens: 800,
      response_format: { type: 'json_object' },
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: buildUserPrompt(inputs) },
      ],
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`OpenAI API error: ${response.status} ${error}`);
  }

  const data = await response.json();
  const content = data.choices[0].message.content;
  const parsed = JSON.parse(content);

  return {
    script: parsed.script,
    word_count: parsed.word_count,
    estimated_duration_sec: parsed.estimated_duration_sec,
    personalization_level_used: parsed.personalization_level_used,
    downgraded_from_c: parsed.downgraded_from_c ?? false,
    notes: parsed.notes ?? '',
    tokens_used: data.usage.total_tokens,
  };
}


// -----------------------------------------------------------------------------
// EXEMPLE D'APPEL ELEVEN LABS (à intégrer dans l'Edge Function)
// -----------------------------------------------------------------------------

const ELEVENLABS_VOICE_ID_ADAM_FR = 'pNInz6obpgDQGcFmaJgB'; // à confirmer dans le dashboard EL

export async function generateAudioFile(
  scriptText: string,
  elevenLabsApiKey: string,
  voiceId: string = ELEVENLABS_VOICE_ID_ADAM_FR
): Promise<{ audioBuffer: ArrayBuffer; charsUsed: number }> {
  const response = await fetch(
    `https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`,
    {
      method: 'POST',
      headers: {
        'Accept': 'audio/mpeg',
        'Content-Type': 'application/json',
        'xi-api-key': elevenLabsApiKey,
      },
      body: JSON.stringify({
        text: scriptText,
        model_id: 'eleven_multilingual_v2',
        voice_settings: {
          stability: 0.55,
          similarity_boost: 0.75,
          style: 0.0,
          use_speaker_boost: true,
        },
        output_format: 'mp3_44100_192',
      }),
    }
  );

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Eleven Labs API error: ${response.status} ${error}`);
  }

  const audioBuffer = await response.arrayBuffer();
  const charsUsed = scriptText.length;

  return { audioBuffer, charsUsed };
}


// =============================================================================
// FIN
// =============================================================================
// Notes pour l'intégration :
//
// 1) La voice_id "pNInz6obpgDQGcFmaJgB" est un placeholder (voix Adam EN).
//    Avant production, créer un compte Eleven Labs, choisir/cloner une voix
//    française, copier son voice_id depuis le dashboard.
//
// 2) Tester le prompt sur 5-10 profils différents avant déploiement.
//    Vérifier : ton OXV respecté, longueur 220-260 mots, aucune formule
//    commerciale, JSON parseable.
//
// 3) Le coût par audio :
//    - GPT-4o : ~500 tokens input + 400 tokens output = ~0,008€
//    - Eleven Labs : 250 mots × ~6 chars = ~1500 chars = ~0,15€ (plan Creator)
//    - Total : ~0,16€ par audio. Sur 32 sessions × 20 pilotes = ~100€/an.
//
// 4) Ajouter un retry exponentiel sur les deux appels API (3 tentatives max).
// =============================================================================
