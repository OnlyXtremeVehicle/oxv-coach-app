// =============================================================================
// supabase/functions/ritual_dryrun/index.ts
// =============================================================================
// Envoie un rituel test à une adresse email, avec des données fictives.
// N'écrit RIEN en base de données. Utilisé par le bouton "Envoi test" de
// la page admin.
//
// IMPORTANT : utilise les MÊMES handlers que ritual_dispatcher, mais avec
// un faux DispatchContext construit en mémoire.
//
// Note d'architecture : pour éviter la duplication, on importe directement
// les handlers depuis ritual_dispatcher. Vous devez donc avoir les deux
// functions déployées dans le même projet Supabase.
//
// Déploiement :
// supabase functions deploy ritual_dryrun --no-verify-jwt
// =============================================================================

import { handleJMinus7 } from '../ritual_dispatcher/handlers/jminus7.ts';
import { handleJMinus2 } from '../ritual_dispatcher/handlers/jminus2.ts';
import { handleJMinus1 } from '../ritual_dispatcher/handlers/jminus1.ts';

interface DryrunRequest {
  ritual_type: 'jminus7' | 'jminus2' | 'jminus1';
  to_email: string;
  pilot_first_name?: string;
  vehicle_label?: string;          // ex: "Porsche 911 GT3"
  session_format?: string;         // ex: "Access"
}

Deno.serve(async (req: Request) => {
  // Sécurité : seul un appel authentifié avec service_role peut déclencher
  const authHeader = req.headers.get('Authorization') ?? '';
  const expectedToken = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';
  if (!authHeader.includes(expectedToken) || expectedToken.length < 20) {
    return jsonResponse({ error: 'Unauthorized' }, 401);
  }

  try {
    const body = (await req.json()) as DryrunRequest;

    if (!body.ritual_type || !body.to_email) {
      return jsonResponse({ error: 'ritual_type et to_email requis' }, 400);
    }

    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(body.to_email)) {
      return jsonResponse({ error: 'Email invalide' }, 400);
    }

    // Construire un faux DispatchContext
    const ctx = buildFakeContext(body);

    // Brancher sur le handler approprié
    let result;
    switch (body.ritual_type) {
      case 'jminus7':
        result = await handleJMinus7(ctx);
        break;
      case 'jminus2':
        result = await handleJMinus2(ctx);
        break;
      case 'jminus1':
        result = await handleJMinus1(ctx);
        break;
      default:
        return jsonResponse({ error: 'ritual_type inconnu' }, 400);
    }

    return jsonResponse({
      ok: true,
      sent_to: body.to_email,
      ritual_type: body.ritual_type,
      resend_message_id: result.resend_message_id,
    });
  } catch (e) {
    console.error('ritual_dryrun error:', e);
    return jsonResponse({ error: (e as Error).message }, 500);
  }
});

// -----------------------------------------------------------------------------
// Construction d'un faux contexte
// -----------------------------------------------------------------------------

function buildFakeContext(body: DryrunRequest) {
  const firstName = body.pilot_first_name || 'Pilote test';
  const vehicleParts = (body.vehicle_label || 'Porsche 911').split(' ');
  const make = vehicleParts[0];
  const model = vehicleParts.slice(1).join(' ') || 'modèle';

  // Date fictive : la session est dans 7 jours (peu importe le rituel, on veut
  // juste des dates cohérentes dans le rendu)
  const sessionDate = new Date(Date.now() + 7 * 86400 * 1000).toISOString().split('T')[0];

  return {
    dispatch: {
      id: `dryrun-${Date.now()}`,
      registration_id: 'dryrun-registration',
      user_id: 'dryrun-user',
      session_id: 'dryrun-session',
      ritual_type: body.ritual_type,
      status: 'generating' as const,
      scheduled_for: new Date().toISOString(),
      attempt_count: 0,
    },
    pilot: {
      id: 'dryrun-user',
      first_name: firstName,
      last_name: 'Test',
      email: body.to_email,
      ritual_jminus7_enabled: true,
      ritual_jminus2_enabled: true,
      ritual_jminus1_enabled: true,
    },
    session: {
      id: 'dryrun-session',
      session_date: sessionDate,
      session_format: body.session_format || 'Access',
    },
    registration: {
      id: 'dryrun-registration',
      ref: 'OXV-DRYRUN01',
    },
    vehicle: {
      make,
      model,
      year: 2024,
    },
  };
}

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}
