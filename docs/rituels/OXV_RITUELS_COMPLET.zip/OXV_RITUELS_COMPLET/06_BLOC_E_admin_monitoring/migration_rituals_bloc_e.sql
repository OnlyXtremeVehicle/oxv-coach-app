-- =============================================================================
-- OXV — Migration complémentaire pour le Bloc E (monitoring + webhook)
-- =============================================================================
-- Version       : 1.0
-- Date          : 22 mai 2026
-- Description   : Ajoute les colonnes de tracking d'ouverture/clic et la table
--                 resend_events pour archiver tous les events bruts reçus.
--
-- Prérequis     : migration_rituals.sql (Bloc A) déjà exécutée.
-- =============================================================================


-- =============================================================================
-- 1. COLONNES DE TRACKING SUR ritual_dispatches
-- =============================================================================

ALTER TABLE public.ritual_dispatches
  ADD COLUMN IF NOT EXISTS delivered_at        timestamptz,
  ADD COLUMN IF NOT EXISTS opened_at           timestamptz,    -- première ouverture
  ADD COLUMN IF NOT EXISTS opened_count        integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS clicked_at          timestamptz,    -- premier clic
  ADD COLUMN IF NOT EXISTS clicked_count       integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS bounced_at          timestamptz,
  ADD COLUMN IF NOT EXISTS bounce_reason       text,
  ADD COLUMN IF NOT EXISTS complained_at       timestamptz;    -- signalé comme spam

-- Index pour les requêtes admin (filtrer les non-ouverts par exemple)
CREATE INDEX IF NOT EXISTS idx_ritual_dispatches_opened
  ON public.ritual_dispatches (opened_at)
  WHERE opened_at IS NOT NULL;


-- =============================================================================
-- 2. TABLE resend_events — archive brute de tous les events reçus
-- =============================================================================
-- Garde une trace complète pour debug et audit.
-- Indépendante de ritual_dispatches : un event peut arriver sans avoir
-- un dispatch associé (ex: emails admin futurs).

CREATE TABLE IF NOT EXISTS public.resend_events (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type      text NOT NULL,            -- 'email.sent', 'email.opened', etc.
  resend_email_id text NOT NULL,            -- correspond à resend_message_id
  dispatch_id     uuid REFERENCES public.ritual_dispatches(id) ON DELETE SET NULL,
  occurred_at     timestamptz NOT NULL,     -- timestamp fourni par Resend
  raw_payload     jsonb NOT NULL,           -- l'event complet pour audit
  processed_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_resend_events_dispatch
  ON public.resend_events (dispatch_id, occurred_at DESC);

CREATE INDEX IF NOT EXISTS idx_resend_events_email
  ON public.resend_events (resend_email_id);

CREATE INDEX IF NOT EXISTS idx_resend_events_type
  ON public.resend_events (event_type, occurred_at DESC);


-- =============================================================================
-- 3. RLS — Row Level Security
-- =============================================================================

ALTER TABLE public.resend_events ENABLE ROW LEVEL SECURITY;

-- Admin lit tout
DROP POLICY IF EXISTS resend_events_select_admin ON public.resend_events;
CREATE POLICY resend_events_select_admin
  ON public.resend_events
  FOR SELECT
  USING (public.is_admin());

-- L'Edge Function utilise service_role qui bypasse RLS.
-- Aucune INSERT/UPDATE/DELETE depuis le client.


-- =============================================================================
-- 4. FONCTION pour appliquer un event à un dispatch
-- =============================================================================
-- Appelée par l'Edge Function resend_webhook après archivage de l'event brut.
-- Centralise la logique de mise à jour pour idempotence (multi-appels OK).

CREATE OR REPLACE FUNCTION public.apply_resend_event(
  p_dispatch_id uuid,
  p_event_type  text,
  p_occurred_at timestamptz,
  p_bounce_reason text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Selon le type d'event, on met à jour les colonnes correspondantes.
  -- COALESCE garantit qu'on ne réécrit pas le first-event timestamp.

  CASE p_event_type
    WHEN 'email.delivered' THEN
      UPDATE public.ritual_dispatches
         SET delivered_at = COALESCE(delivered_at, p_occurred_at)
       WHERE id = p_dispatch_id;

    WHEN 'email.opened' THEN
      UPDATE public.ritual_dispatches
         SET opened_at = COALESCE(opened_at, p_occurred_at),
             opened_count = opened_count + 1
       WHERE id = p_dispatch_id;

    WHEN 'email.clicked' THEN
      UPDATE public.ritual_dispatches
         SET clicked_at = COALESCE(clicked_at, p_occurred_at),
             clicked_count = clicked_count + 1
       WHERE id = p_dispatch_id;

    WHEN 'email.bounced' THEN
      UPDATE public.ritual_dispatches
         SET bounced_at = COALESCE(bounced_at, p_occurred_at),
             bounce_reason = COALESCE(bounce_reason, p_bounce_reason)
       WHERE id = p_dispatch_id;

    WHEN 'email.complained' THEN
      UPDATE public.ritual_dispatches
         SET complained_at = COALESCE(complained_at, p_occurred_at)
       WHERE id = p_dispatch_id;

    ELSE
      -- email.sent, email.delivery_delayed, ou autres → on archive juste l'event
      -- sans modifier ritual_dispatches.
      NULL;
  END CASE;
END;
$$;


-- =============================================================================
-- 5. VUE D'ADMIN ENRICHIE avec tracking
-- =============================================================================

CREATE OR REPLACE VIEW public.admin_ritual_dispatches_view AS
SELECT
  rd.id,
  rd.ritual_type,
  rd.status,
  rd.scheduled_for,
  rd.sent_at,
  rd.delivered_at,
  rd.opened_at,
  rd.opened_count,
  rd.clicked_at,
  rd.clicked_count,
  rd.bounced_at,
  rd.bounce_reason,
  rd.complained_at,
  rd.attempt_count,
  rd.last_error,
  rd.audio_storage_path,
  rd.audio_duration_sec,
  rd.resend_message_id,
  rd.payload,
  rd.openai_tokens_used,
  rd.elevenlabs_chars,
  rd.created_at,
  rd.updated_at,

  -- Pilote
  u.id              AS user_id,
  u.first_name      AS pilot_first_name,
  u.last_name       AS pilot_last_name,
  u.email           AS pilot_email,

  -- Session
  s.id              AS session_id,
  s.session_date    AS session_date,
  s.session_format  AS session_format,

  -- Registration
  r.id              AS registration_id,
  r.ref             AS registration_ref

FROM public.ritual_dispatches rd
JOIN public.users         u ON u.id = rd.user_id
JOIN public.sessions      s ON s.id = rd.session_id
JOIN public.registrations r ON r.id = rd.registration_id;


-- =============================================================================
-- 6. FONCTION RPC pour la page admin : stats globales
-- =============================================================================

CREATE OR REPLACE FUNCTION public.admin_ritual_stats(
  p_days_back integer DEFAULT 30
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_result jsonb;
  v_since  timestamptz;
BEGIN
  -- Vérification admin
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Forbidden';
  END IF;

  v_since := now() - (p_days_back || ' days')::interval;

  SELECT jsonb_build_object(
    'period_days', p_days_back,
    'total', count(*),
    'by_status', jsonb_object_agg(status, status_count),
    'by_type', (
      SELECT jsonb_object_agg(ritual_type, type_count)
      FROM (
        SELECT ritual_type, count(*) AS type_count
        FROM public.ritual_dispatches
        WHERE created_at >= v_since
        GROUP BY ritual_type
      ) t
    ),
    'engagement', jsonb_build_object(
      'sent', sum(CASE WHEN status = 'sent' THEN 1 ELSE 0 END),
      'delivered', sum(CASE WHEN delivered_at IS NOT NULL THEN 1 ELSE 0 END),
      'opened', sum(CASE WHEN opened_at IS NOT NULL THEN 1 ELSE 0 END),
      'clicked', sum(CASE WHEN clicked_at IS NOT NULL THEN 1 ELSE 0 END),
      'bounced', sum(CASE WHEN bounced_at IS NOT NULL THEN 1 ELSE 0 END)
    ),
    'cost_estimate_eur', round(
      (sum(coalesce(openai_tokens_used, 0)) * 0.00001 +
       sum(coalesce(elevenlabs_chars, 0)) * 0.0001)::numeric,
      2
    )
  ) INTO v_result
  FROM (
    SELECT status, count(*) AS status_count
    FROM public.ritual_dispatches
    WHERE created_at >= v_since
    GROUP BY status
  ) s, public.ritual_dispatches
  WHERE created_at >= v_since;

  RETURN COALESCE(v_result, '{}'::jsonb);
END;
$$;


-- =============================================================================
-- FIN DE LA MIGRATION
-- =============================================================================
-- Vérifications :
--
-- 1) Nouvelles colonnes :
--    SELECT column_name FROM information_schema.columns
--    WHERE table_name = 'ritual_dispatches' AND column_name LIKE '%_at';
--
-- 2) Table resend_events :
--    SELECT count(*) FROM public.resend_events;
--
-- 3) Tester la fonction stats :
--    SELECT public.admin_ritual_stats(30);
-- =============================================================================
