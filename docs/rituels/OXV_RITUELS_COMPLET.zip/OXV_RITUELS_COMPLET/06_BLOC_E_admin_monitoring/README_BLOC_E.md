# Bloc E — Page admin de monitoring + Webhook Resend

> Niveau Complet : monitoring + relance + audio player + tracking ouvertures/clics + dry run + export CSV

---

## Contenu du livrable

```
bloc_e/
├── admin-rituels.html        # Markup HTML à intégrer dans index.html
├── admin-rituels.css         # Styles à fusionner avec votre CSS
├── admin-rituels.js          # Logique JavaScript de la page
├── README_BLOC_E.md          # Ce fichier
└── supabase/
    └── functions/
        ├── resend_webhook/
        │   └── index.ts      # Edge Function de réception des events Resend
        └── ritual_dryrun/
            └── index.ts      # Edge Function pour les envois test (bouton dry run)
```

À noter : `migration_rituals_bloc_e.sql` est livré séparément à la racine des outputs.

---

## Étapes d'installation

### 1. Migration SQL complémentaire

Exécuter `migration_rituals_bloc_e.sql` dans le SQL Editor Supabase.

**Vérifications post-migration** :

```sql
-- Nouvelles colonnes sur ritual_dispatches
SELECT column_name FROM information_schema.columns
WHERE table_name = 'ritual_dispatches' AND column_name IN ('delivered_at', 'opened_at', 'clicked_at', 'bounced_at');
-- Attendu : 4 lignes

-- Table resend_events
SELECT count(*) FROM public.resend_events;
-- Attendu : 0 (vide au départ)

-- Tester la fonction stats
SELECT public.admin_ritual_stats(30);
-- Attendu : JSON avec des compteurs à 0 si aucun dispatch existant
```

---

### 2. Déployer la function `resend_webhook`

```bash
cd <racine_du_projet>
supabase functions deploy resend_webhook --no-verify-jwt
```

**Récupérer l'URL de la function** :
```
https://fouvuqkdxarjpjbqnsjq.supabase.co/functions/v1/resend_webhook
```

---

### 3. Configurer le webhook côté Resend

1. Dashboard Resend → **Webhooks** → **Add Endpoint**
2. **URL** : `https://fouvuqkdxarjpjbqnsjq.supabase.co/functions/v1/resend_webhook`
3. **Events à activer** :
   - ✅ `email.sent`
   - ✅ `email.delivered`
   - ✅ `email.delivery_delayed`
   - ✅ `email.bounced`
   - ✅ `email.opened`
   - ✅ `email.clicked`
   - ✅ `email.complained`
4. **Create** → Resend génère un **Signing Secret**
5. Copier ce secret et le stocker dans Supabase :

```bash
supabase secrets set RESEND_WEBHOOK_SECRET=whsec_...
```

**Test du webhook** :
- Resend Dashboard → onglet du webhook → **Send test event**
- Vérifier dans les logs Supabase :
  ```bash
  supabase functions logs resend_webhook --tail
  ```
- Vérifier en SQL :
  ```sql
  SELECT * FROM resend_events ORDER BY processed_at DESC LIMIT 5;
  ```

---

### 4. Déployer la function `ritual_dryrun`

```bash
supabase functions deploy ritual_dryrun --no-verify-jwt
```

**Test rapide** :
```bash
curl -X POST \
  https://fouvuqkdxarjpjbqnsjq.supabase.co/functions/v1/ritual_dryrun \
  -H "Authorization: Bearer <SERVICE_ROLE_KEY>" \
  -H "Content-Type: application/json" \
  -d '{
    "ritual_type": "jminus7",
    "to_email": "votre.email@example.com",
    "pilot_first_name": "Gabin",
    "vehicle_label": "Porsche 911 GT3",
    "session_format": "Access"
  }'
```

Vous devez recevoir l'email J-7 dans la boîte indiquée, avec des données fictives.

---

### 5. Intégrer la page admin à `index.html`

#### A) Coller le markup HTML

Copier le contenu de `admin-rituels.html` à l'endroit approprié dans votre `index.html`,
au même niveau que vos autres `<section id="page-admin-*">` existantes.

Le markup contient **3 éléments** :
- La section principale `<section id="page-admin-rituels">`
- Le drawer de détail `<div id="dispatch-detail-drawer">`
- Le modal dry run `<div id="dryrun-modal">`

#### B) Fusionner le CSS

Copier le contenu de `admin-rituels.css` dans votre `<style>` ou fichier CSS.

**Conflits possibles** avec votre CSS existant :
- `.btn`, `.btn--primary`, `.btn--secondary` : si vous avez déjà ces classes, vérifier que les styles correspondent (ou renommer en `.btn-rituels`)
- `.eyebrow` : sans doute déjà défini chez vous, à mutualiser
- `.form-input`, `.form-select`, `.form-label` : pareil
- `.kpi-card` : déjà utilisée sur votre tableau de bord admin ? À fusionner

#### C) Charger le JavaScript

Copier `admin-rituels.js` dans une balise `<script>` à la fin de votre `<body>`,
ou dans votre fichier JS principal.

**Prérequis dans votre code existant** :

```javascript
// Avant le chargement de admin-rituels.js, vous devez exposer :
window.OXV = {
  supabase: supabaseClient,  // votre instance Supabase JS déjà initialisée
  isAdmin: true,             // résultat de votre check is_admin()
  showPage: showPage,        // votre fonction de routing single-page
};
```

#### D) Brancher le routing

Quand l'utilisateur navigue vers la page admin rituels (clic sur un lien de navigation),
votre code de routing doit :

1. Vérifier `window.OXV.isAdmin === true`
2. Cacher les autres sections `<section class="page">`
3. Afficher `<section id="page-admin-rituels">` (`hidden = false`)
4. Appeler `window.OXV.showAdminRituels()` pour déclencher le chargement initial

Exemple :

```javascript
function navigateToAdminRituels() {
  if (!window.OXV.isAdmin) return;
  document.querySelectorAll('.page').forEach(p => p.hidden = true);
  document.getElementById('page-admin-rituels').hidden = false;
  window.OXV.showAdminRituels();
}
```

---

### 6. Ajouter un lien de navigation admin

Dans votre menu admin existant (sidebar ou top nav), ajouter une entrée :

```html
<a href="#admin-rituels" class="admin-nav__link" data-route="admin-rituels">
  <span class="admin-nav__icon">✉</span>
  Rituels
</a>
```

Et brancher le clic sur `navigateToAdminRituels()` (voir étape 5).

---

## Vérifications fonctionnelles

Une fois tout déployé :

### Test 1 : La page se charge

- Navigation → Rituels
- Les 5 KPIs s'affichent (probablement à 0 si vous n'avez pas encore de données)
- Le tableau dit "Aucun dispatch sur cette période" si vide

### Test 2 : Dry run

- Bouton "Envoi test" → Modal s'ouvre
- Sélectionner J-7, mettre votre email
- Envoyer → Email reçu en quelques secondes
- Refaire avec J-2 (attention, ça déclenche OpenAI + Eleven Labs, coût ~0,16€)
- Refaire avec J-1 (météo réelle La Génétouze)

### Test 3 : Le webhook fonctionne

- Ouvrir l'un des emails de test reçus
- Attendre 1-2 minutes
- Recharger la page admin → l'event `opened` devrait apparaître si le dispatch existait en DB. Pour les dry runs, les events arrivent dans `resend_events` mais ne lient à aucun `dispatch_id` (c'est normal — pas de dispatch créé pour les dry runs)

### Test 4 : Relance d'un dispatch failed

- Créer manuellement un dispatch en statut `failed` :
  ```sql
  UPDATE ritual_dispatches SET status = 'failed', last_error = 'test' WHERE id = '<UUID>';
  ```
- Recharger la page → la ligne apparaît avec un bouton "Relancer"
- Cliquer "Relancer" → confirmation → le dispatch repasse en `pending`
- Attendre le prochain cycle pg_cron OU appeler manuellement `ritual_dispatcher` via curl
- Le dispatch passe en `sent`

---

## Surveillance et debug

### Logs en temps réel

```bash
supabase functions logs resend_webhook --tail
supabase functions logs ritual_dispatcher --tail
supabase functions logs ritual_dryrun --tail
```

### Vérifier les events Resend bruts

```sql
SELECT event_type, occurred_at, dispatch_id IS NOT NULL AS matched
FROM public.resend_events
ORDER BY occurred_at DESC
LIMIT 20;
```

### Dispatches sans tracking d'ouverture (Resend down ?)

```sql
SELECT count(*) FROM ritual_dispatches
WHERE status = 'sent' AND delivered_at IS NULL
  AND sent_at < now() - interval '1 hour';
```

Si > 0 et que vous avez configuré le webhook : il y a un problème côté Resend ou côté
signature webhook. Vérifier les logs.

---

## Coûts du Bloc E

| Élément | Coût |
|---|---|
| Edge Function `resend_webhook` | 0 € (incluse dans plan Free) |
| Edge Function `ritual_dryrun` | 0 € (incluse) |
| Webhook Resend | 0 € (inclus dans tous les plans Resend) |
| Storage `resend_events` (volume) | Négligeable (~100 Ko/an) |
| **TOTAL** | **0 €** |

Le seul coût variable, ce sont les dry runs J-2 qui consomment GPT-4o + Eleven Labs.
Tester avec modération (4-5 J-2 tests = ~1€).

---

## Limites connues

1. **Le dispatch_id n'est pas matché pour les dry runs**. C'est volontaire : les dry runs
   n'écrivent rien en DB, donc Resend retourne un email_id qui ne correspond à aucun
   dispatch. Les events sont quand même archivés dans `resend_events` pour debug.

2. **Les conflits CSS**. Si votre `index.html` a déjà des classes `.btn`, `.modal`, `.drawer`,
   il faudra renommer ou fusionner. Pas de cassure cachée, juste à vérifier visuellement.

3. **La fonction `admin_ritual_stats`** suppose que `is_admin()` est défini chez vous.
   Si pas le cas (peu probable vu votre setup), à remplacer par votre check admin.

4. **Pas de pagination cursor-based**. Pour 10 000+ dispatches en base, l'offset-based
   `range(from, to)` devient lent. Solution v2 : passer en cursor-based avec
   `gt('scheduled_for', last_seen)`.

5. **Pas de WebSocket pour le live update**. La page se rafraîchit au clic sur "Actualiser".
   Pas critique pour un outil admin interne.

---

## Architecture finale après Blocs A à E

```
                    ┌─────────────────────────┐
                    │   Pilote (oxvehicle.fr) │
                    └────────────┬────────────┘
                                 │
              ┌──────────────────┼──────────────────┐
              ▼                  ▼                  ▼
        Email J-7         Email J-2 + MP3      Email J-1
              │                  │                  │
              ▼                  ▼                  ▼
        ┌────────────────────────────────────────────────┐
        │              Resend                             │
        │  Events: sent, delivered, opened, clicked       │
        └─────────────────────┬──────────────────────────┘
                              │
                              ▼ (webhook)
        ┌────────────────────────────────────────────────┐
        │  Edge Function : resend_webhook                │
        │  → archive resend_events                       │
        │  → applique aux ritual_dispatches              │
        └────────────────────────────────────────────────┘

        ┌────────────────────────────────────────────────┐
        │  pg_cron (toutes les heures 16h-19h UTC)       │
        │  → POST ritual_dispatcher                      │
        └─────────────────────┬──────────────────────────┘
                              │
                              ▼
        ┌────────────────────────────────────────────────┐
        │  Edge Function : ritual_dispatcher             │
        │  → handlers/jminus7, jminus2, jminus1          │
        │  → OpenAI + Eleven Labs + Open-Meteo + Resend  │
        └────────────────────────────────────────────────┘

        ┌────────────────────────────────────────────────┐
        │  Page admin (index.html)                       │
        │  → monitoring, stats, relance, dry run, export │
        └────────────────────────────────────────────────┘
```

---

*Bloc E livré le 22 mai 2026. Système OXV de rituels pré-session complet de A à E.*
