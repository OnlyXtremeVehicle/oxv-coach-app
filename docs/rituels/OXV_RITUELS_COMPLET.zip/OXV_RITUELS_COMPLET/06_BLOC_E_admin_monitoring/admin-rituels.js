/* =========================================================================
   Page admin — Rituels pré-session · Logique JavaScript
   À intégrer avec votre système de routing et votre client Supabase existant.
   ========================================================================= */

(function () {
  'use strict';

  // ---------------------------------------------------------------------
  // Configuration
  // ---------------------------------------------------------------------
  // Adaptez ces accesseurs à votre architecture existante.
  // - window.OXV.supabase : votre client Supabase JS déjà initialisé
  // - window.OXV.isAdmin  : booléen (vous devez le vérifier avant d'afficher la page)
  // - window.OXV.showPage : votre fonction de routing single-page

  const PAGE_SIZE = 20;
  const STATE = {
    currentPage: 1,
    totalRows: 0,
    filters: {
      ritual_type: '',
      status: '',
      pilot_query: '',
      period: '30',
    },
    rows: [],
    selectedDispatchId: null,
  };

  // ---------------------------------------------------------------------
  // Initialisation
  // ---------------------------------------------------------------------

  function init() {
    const section = document.getElementById('page-admin-rituels');
    if (!section) {
      console.warn('[admin-rituels] page-admin-rituels introuvable');
      return;
    }
    bindEvents();
    // À appeler depuis votre router quand l'utilisateur accède à la page
    window.OXV = window.OXV || {};
    window.OXV.showAdminRituels = openPage;
  }

  function openPage() {
    // Réinitialiser et charger
    STATE.currentPage = 1;
    loadStats();
    loadRows();
  }

  // ---------------------------------------------------------------------
  // Event bindings
  // ---------------------------------------------------------------------

  function bindEvents() {
    document.addEventListener('click', (e) => {
      const target = e.target.closest('[data-action]');
      if (!target) return;
      const action = target.dataset.action;
      switch (action) {
        case 'refresh':         openPage(); break;
        case 'reset-filters':   resetFilters(); break;
        case 'export-csv':      exportCsv(); break;
        case 'prev-page':       changePage(-1); break;
        case 'next-page':       changePage(1); break;
        case 'open-dryrun':     openDryrun(); break;
        case 'close-dryrun':    closeDryrun(); break;
        case 'submit-dryrun':   submitDryrun(); break;
        case 'close-drawer':    closeDrawer(); break;
        case 'relaunch':        relaunchDispatch(target.dataset.id); break;
      }
    });

    document.addEventListener('change', (e) => {
      const target = e.target.closest('[data-filter]');
      if (!target) return;
      STATE.filters[target.dataset.filter] = target.value;
      STATE.currentPage = 1;
      loadRows();
    });

    document.addEventListener('input', debounce((e) => {
      const target = e.target.closest('[data-filter="pilot_query"]');
      if (!target) return;
      STATE.filters.pilot_query = target.value;
      STATE.currentPage = 1;
      loadRows();
    }, 350));

    document.addEventListener('click', (e) => {
      const row = e.target.closest('[data-row-id]');
      if (row && !e.target.closest('[data-action]')) {
        openDrawer(row.dataset.rowId);
      }
    });
  }

  function debounce(fn, ms) {
    let t;
    return (...args) => {
      clearTimeout(t);
      t = setTimeout(() => fn(...args), ms);
    };
  }

  // ---------------------------------------------------------------------
  // Stats globales
  // ---------------------------------------------------------------------

  async function loadStats() {
    const sb = window.OXV?.supabase;
    if (!sb) return;

    const { data, error } = await sb.rpc('admin_ritual_stats', {
      p_days_back: parseInt(STATE.filters.period, 10),
    });
    if (error) {
      console.error('[admin-rituels] loadStats:', error);
      return;
    }
    renderStats(data);
  }

  function renderStats(stats) {
    const container = document.querySelector('[data-stats-container]');
    if (!container) return;

    const sent       = stats?.engagement?.sent       ?? 0;
    const delivered  = stats?.engagement?.delivered  ?? 0;
    const opened     = stats?.engagement?.opened     ?? 0;
    const clicked    = stats?.engagement?.clicked    ?? 0;
    const total      = stats?.total                  ?? 0;
    const cost       = stats?.cost_estimate_eur      ?? 0;

    const openRate = sent > 0 ? Math.round((opened / sent) * 100) : 0;
    const clickRate = sent > 0 ? Math.round((clicked / sent) * 100) : 0;

    container.innerHTML = `
      <div class="kpi-card kpi-card--accent">
        <p class="kpi-card__label">Total ${stats.period_days}j</p>
        <p class="kpi-card__value">${total}</p>
        <p class="kpi-card__delta">${sent} envoyés</p>
      </div>
      <div class="kpi-card">
        <p class="kpi-card__label">Taux d'ouverture</p>
        <p class="kpi-card__value">${openRate}%</p>
        <p class="kpi-card__delta">${opened} / ${sent}</p>
      </div>
      <div class="kpi-card">
        <p class="kpi-card__label">Taux de clic</p>
        <p class="kpi-card__value">${clickRate}%</p>
        <p class="kpi-card__delta">${clicked} / ${sent}</p>
      </div>
      <div class="kpi-card">
        <p class="kpi-card__label">Échecs</p>
        <p class="kpi-card__value">${stats.by_status?.failed ?? 0}</p>
        <p class="kpi-card__delta ${(stats.by_status?.failed ?? 0) > 0 ? 'kpi-card__delta--danger' : ''}">${(stats.by_status?.failed ?? 0) > 0 ? 'À traiter' : 'Aucun'}</p>
      </div>
      <div class="kpi-card">
        <p class="kpi-card__label">Coût estimé</p>
        <p class="kpi-card__value">${cost.toFixed(2)}€</p>
        <p class="kpi-card__delta">Période</p>
      </div>
    `;
  }

  // ---------------------------------------------------------------------
  // Liste des dispatches
  // ---------------------------------------------------------------------

  async function loadRows() {
    const sb = window.OXV?.supabase;
    if (!sb) return;

    const tbody = document.querySelector('[data-rows-container]');
    tbody.innerHTML = '<tr class="admin-table__empty"><td colspan="8">Chargement...</td></tr>';

    // Construire la query Supabase
    const since = new Date(Date.now() - parseInt(STATE.filters.period, 10) * 86400 * 1000).toISOString();

    let query = sb
      .from('admin_ritual_dispatches_view')
      .select('*', { count: 'exact' })
      .gte('created_at', since)
      .order('scheduled_for', { ascending: false });

    if (STATE.filters.ritual_type) query = query.eq('ritual_type', STATE.filters.ritual_type);
    if (STATE.filters.status)      query = query.eq('status', STATE.filters.status);
    if (STATE.filters.pilot_query) {
      const q = STATE.filters.pilot_query.trim();
      query = query.or(`pilot_email.ilike.%${q}%,pilot_first_name.ilike.%${q}%,pilot_last_name.ilike.%${q}%`);
    }

    const from = (STATE.currentPage - 1) * PAGE_SIZE;
    const to = from + PAGE_SIZE - 1;
    query = query.range(from, to);

    const { data, error, count } = await query;
    if (error) {
      console.error('[admin-rituels] loadRows:', error);
      tbody.innerHTML = `<tr class="admin-table__empty"><td colspan="8">Erreur: ${escapeHtml(error.message)}</td></tr>`;
      return;
    }

    STATE.rows = data ?? [];
    STATE.totalRows = count ?? 0;
    renderRows(STATE.rows);
    renderPagination();
  }

  function renderRows(rows) {
    const tbody = document.querySelector('[data-rows-container]');
    if (rows.length === 0) {
      tbody.innerHTML = '<tr class="admin-table__empty"><td colspan="8">Aucun dispatch sur cette période avec ces filtres.</td></tr>';
      return;
    }

    tbody.innerHTML = rows.map(row => `
      <tr data-row-id="${row.id}">
        <td class="col-status">${renderStatusBadge(row.status)}</td>
        <td class="col-type">${renderTypeBadge(row.ritual_type)}</td>
        <td>
          <div class="cell-pilot">
            <span class="cell-pilot__name">${escapeHtml(row.pilot_first_name ?? '')} ${escapeHtml(row.pilot_last_name ?? '')}</span>
            <span class="cell-pilot__email">${escapeHtml(row.pilot_email ?? '')}</span>
          </div>
        </td>
        <td>${formatSessionLabel(row.session_date, row.session_format)}</td>
        <td>${formatDateTime(row.scheduled_for)}</td>
        <td>${row.sent_at ? formatDateTime(row.sent_at) : '<span style="color:#6B6B6B">—</span>'}</td>
        <td>${renderEngagement(row)}</td>
        <td class="col-actions">${renderRowActions(row)}</td>
      </tr>
    `).join('');
  }

  function renderStatusBadge(status) {
    const labels = {
      pending: 'En attente', generating: 'En cours', sent: 'Envoyé',
      failed: 'Échec', skipped: 'Ignoré',
    };
    return `<span class="status-badge status-badge--${status}"><span class="status-badge__dot"></span>${labels[status] ?? status}</span>`;
  }

  function renderTypeBadge(type) {
    const labels = { jminus7: 'J-7', jminus2: 'J-2', jminus1: 'J-1' };
    return `<span class="ritual-badge ritual-badge--${type}">${labels[type] ?? type}</span>`;
  }

  function renderEngagement(row) {
    if (row.status !== 'sent') return '<span style="color:#6B6B6B;font-size:11px">—</span>';
    const delivered = row.delivered_at ? '✓' : '·';
    const opened = row.opened_at ? `✓ ${row.opened_count}×` : '·';
    const clicked = row.clicked_at ? `✓ ${row.clicked_count}×` : '·';
    return `
      <div class="engagement-cell">
        <span class="engagement-row ${row.delivered_at ? 'engagement-row--filled' : ''}"><span class="engagement-row__icon">→</span> Livré ${delivered}</span>
        <span class="engagement-row ${row.opened_at ? 'engagement-row--filled' : ''}"><span class="engagement-row__icon">●</span> Ouvert ${opened}</span>
        <span class="engagement-row ${row.clicked_at ? 'engagement-row--filled' : ''}"><span class="engagement-row__icon">↗</span> Cliqué ${clicked}</span>
      </div>
    `;
  }

  function renderRowActions(row) {
    if (row.status === 'failed') {
      return `<button type="button" class="btn btn--text btn--sm" data-action="relaunch" data-id="${row.id}" onclick="event.stopPropagation()">Relancer</button>`;
    }
    return '<span style="color:#6B6B6B;font-size:11px">—</span>';
  }

  function renderPagination() {
    const info = document.querySelector('[data-pagination-info]');
    const current = document.querySelector('[data-pagination-current]');
    const prevBtn = document.querySelector('[data-action="prev-page"]');
    const nextBtn = document.querySelector('[data-action="next-page"]');

    const totalPages = Math.max(1, Math.ceil(STATE.totalRows / PAGE_SIZE));
    const from = (STATE.currentPage - 1) * PAGE_SIZE + 1;
    const to = Math.min(STATE.currentPage * PAGE_SIZE, STATE.totalRows);

    info.textContent = STATE.totalRows > 0
      ? `${from}–${to} sur ${STATE.totalRows}`
      : 'Aucun résultat';
    current.textContent = `Page ${STATE.currentPage} / ${totalPages}`;
    prevBtn.disabled = STATE.currentPage <= 1;
    nextBtn.disabled = STATE.currentPage >= totalPages;
  }

  function changePage(delta) {
    STATE.currentPage = Math.max(1, STATE.currentPage + delta);
    loadRows();
  }

  function resetFilters() {
    STATE.filters = { ritual_type: '', status: '', pilot_query: '', period: '30' };
    document.querySelectorAll('[data-filter]').forEach(el => {
      el.value = el.dataset.filter === 'period' ? '30' : '';
    });
    STATE.currentPage = 1;
    loadStats();
    loadRows();
  }

  // ---------------------------------------------------------------------
  // Drawer détail
  // ---------------------------------------------------------------------

  async function openDrawer(dispatchId) {
    STATE.selectedDispatchId = dispatchId;
    const drawer = document.getElementById('dispatch-detail-drawer');
    drawer.hidden = false;

    const row = STATE.rows.find(r => r.id === dispatchId);
    if (!row) return;

    const eyebrow = document.querySelector('[data-drawer-eyebrow]');
    const title = document.querySelector('[data-drawer-title]');
    const body = document.querySelector('[data-drawer-body]');
    const footer = document.querySelector('[data-drawer-footer]');

    const typeLabels = { jminus7: 'J−7 · CONFIRMATION', jminus2: 'J−2 · AUDIO BRIEFING', jminus1: 'J−1 · DERNIER MOT' };
    eyebrow.textContent = typeLabels[row.ritual_type] ?? row.ritual_type;
    title.textContent = `${row.pilot_first_name} ${row.pilot_last_name} — ${formatSessionLabel(row.session_date)}`;

    // Construire le contenu
    body.innerHTML = renderDrawerContent(row);

    // Si J-2 et audio existe → générer une URL signée fraîche
    if (row.ritual_type === 'jminus2' && row.audio_storage_path) {
      await injectAudioPlayer(row.audio_storage_path);
    }

    // Footer actions
    footer.innerHTML = renderDrawerActions(row);
  }

  function renderDrawerContent(row) {
    const payload = row.payload || {};
    const scriptText = payload.script_text || null;

    let html = `
      <section class="drawer__section">
        <p class="drawer__section-label">État</p>
        ${renderStatusBadge(row.status)}
        ${row.last_error ? `<p style="margin-top:8px;color:#C8102E;font-size:13px">${escapeHtml(row.last_error)}</p>` : ''}
      </section>

      <section class="drawer__section">
        <p class="drawer__section-label">Pilote & session</p>
        <div class="drawer__info-grid">
          <span class="drawer__info-key">Pilote</span><span class="drawer__info-val">${escapeHtml(row.pilot_first_name)} ${escapeHtml(row.pilot_last_name)}</span>
          <span class="drawer__info-key">Email</span><span class="drawer__info-val">${escapeHtml(row.pilot_email)}</span>
          <span class="drawer__info-key">Référence</span><span class="drawer__info-val">${escapeHtml(row.registration_ref ?? '—')}</span>
          <span class="drawer__info-key">Session</span><span class="drawer__info-val">${formatSessionLabel(row.session_date, row.session_format)}</span>
        </div>
      </section>

      <section class="drawer__section">
        <p class="drawer__section-label">Calendrier</p>
        <div class="drawer__info-grid">
          <span class="drawer__info-key">Planifié</span><span class="drawer__info-val">${formatDateTime(row.scheduled_for)}</span>
          <span class="drawer__info-key">Envoyé</span><span class="drawer__info-val">${row.sent_at ? formatDateTime(row.sent_at) : '—'}</span>
          <span class="drawer__info-key">Livré</span><span class="drawer__info-val">${row.delivered_at ? formatDateTime(row.delivered_at) : '—'}</span>
          <span class="drawer__info-key">Ouvert</span><span class="drawer__info-val">${row.opened_at ? `${formatDateTime(row.opened_at)} (${row.opened_count}×)` : '—'}</span>
          <span class="drawer__info-key">Cliqué</span><span class="drawer__info-val">${row.clicked_at ? `${formatDateTime(row.clicked_at)} (${row.clicked_count}×)` : '—'}</span>
        </div>
      </section>
    `;

    if (row.ritual_type === 'jminus2' && row.audio_storage_path) {
      html += `
        <section class="drawer__section">
          <p class="drawer__section-label">Audio généré (${row.audio_duration_sec ?? '?'}s)</p>
          <div data-audio-player-container><p style="color:#6B6B6B;font-size:13px">Génération du lien signé...</p></div>
        </section>
      `;
    }

    if (scriptText) {
      html += `
        <section class="drawer__section">
          <p class="drawer__section-label">Script audio</p>
          <div class="drawer__script">${escapeHtml(scriptText)}</div>
          ${payload.personalization_level_used ? `<p style="margin-top:8px;color:#6B6B6B;font-size:12px">Niveau ${payload.personalization_level_used}${payload.downgraded_from_c ? ' (dégradé depuis C)' : ''} · ${payload.script_word_count ?? '?'} mots</p>` : ''}
        </section>
      `;
    }

    html += `
      <section class="drawer__section">
        <p class="drawer__section-label">Payload technique</p>
        <pre class="drawer__payload">${escapeHtml(JSON.stringify(payload, null, 2))}</pre>
      </section>
    `;

    return html;
  }

  async function injectAudioPlayer(storagePath) {
    const sb = window.OXV?.supabase;
    if (!sb) return;
    const container = document.querySelector('[data-audio-player-container]');
    if (!container) return;

    const { data, error } = await sb.storage
      .from('audio_briefings')
      .createSignedUrl(storagePath, 3600); // 1h pour l'admin

    if (error || !data?.signedUrl) {
      container.innerHTML = `<p style="color:#C8102E;font-size:13px">Impossible de générer le lien : ${escapeHtml(error?.message ?? 'erreur inconnue')}</p>`;
      return;
    }

    container.innerHTML = `<audio controls class="drawer__audio-player" src="${data.signedUrl}"></audio>`;
  }

  function renderDrawerActions(row) {
    if (row.status === 'failed') {
      return `<button type="button" class="btn btn--secondary" data-action="close-drawer">Fermer</button>
              <button type="button" class="btn btn--danger" data-action="relaunch" data-id="${row.id}">Relancer ce dispatch</button>`;
    }
    return `<button type="button" class="btn btn--secondary" data-action="close-drawer">Fermer</button>`;
  }

  function closeDrawer() {
    document.getElementById('dispatch-detail-drawer').hidden = true;
    STATE.selectedDispatchId = null;
  }

  // ---------------------------------------------------------------------
  // Relance d'un dispatch failed
  // ---------------------------------------------------------------------

  async function relaunchDispatch(id) {
    if (!id) return;
    if (!confirm('Relancer ce dispatch ? Il repassera en attente et sera retraité au prochain cycle (ou immédiatement via un appel manuel).')) return;

    const sb = window.OXV?.supabase;
    const { error } = await sb
      .from('ritual_dispatches')
      .update({ status: 'pending', last_error: null, attempt_count: 0 })
      .eq('id', id);

    if (error) {
      alert('Erreur : ' + error.message);
      return;
    }
    closeDrawer();
    loadRows();
  }

  // ---------------------------------------------------------------------
  // Export CSV
  // ---------------------------------------------------------------------

  function exportCsv() {
    if (STATE.rows.length === 0) {
      alert('Aucune donnée à exporter sur la page courante. Ajustez les filtres.');
      return;
    }

    const headers = ['ID', 'Rituel', 'Statut', 'Pilote', 'Email', 'Session', 'Format', 'Planifié', 'Envoyé', 'Livré', 'Ouvert', 'Cliqué', 'Erreur'];
    const lines = [headers.join(',')];

    STATE.rows.forEach(row => {
      lines.push([
        row.id,
        row.ritual_type,
        row.status,
        `"${row.pilot_first_name ?? ''} ${row.pilot_last_name ?? ''}"`,
        row.pilot_email ?? '',
        row.session_date ?? '',
        row.session_format ?? '',
        row.scheduled_for ?? '',
        row.sent_at ?? '',
        row.delivered_at ?? '',
        row.opened_at ?? '',
        row.clicked_at ?? '',
        `"${(row.last_error ?? '').replace(/"/g, '""')}"`,
      ].join(','));
    });

    const csv = '\ufeff' + lines.join('\n'); // BOM UTF-8 pour Excel
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `oxv_rituels_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  // ---------------------------------------------------------------------
  // Envoi test (dry run)
  // ---------------------------------------------------------------------

  function openDryrun() {
    document.getElementById('dryrun-modal').hidden = false;
  }

  function closeDryrun() {
    document.getElementById('dryrun-modal').hidden = true;
    document.querySelector('[data-dryrun-alert]').hidden = true;
  }

  async function submitDryrun() {
    const sb = window.OXV?.supabase;
    if (!sb) return;

    const ritualType = document.getElementById('dryrun-type').value;
    const email = document.getElementById('dryrun-email').value.trim();
    const pilotName = document.getElementById('dryrun-pilot-name').value.trim() || 'Pilote test';
    const vehicle = document.getElementById('dryrun-vehicle').value.trim() || 'Porsche 911';
    const format = document.getElementById('dryrun-format').value;

    const alertBox = document.querySelector('[data-dryrun-alert]');
    const alertMsg = document.querySelector('[data-dryrun-alert-message]');
    const submitLabel = document.querySelector('[data-dryrun-submit-label]');

    alertBox.hidden = true;

    if (!email || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
      alertBox.hidden = false;
      alertMsg.textContent = 'Email invalide.';
      return;
    }

    submitLabel.textContent = 'Envoi en cours...';

    // Appel d'une RPC dédiée OU d'une Edge Function dryrun.
    // Implémentation côté serveur : voir README_BLOC_E.md.
    try {
      const { data, error } = await sb.functions.invoke('ritual_dryrun', {
        body: {
          ritual_type: ritualType,
          to_email: email,
          pilot_first_name: pilotName,
          vehicle_label: vehicle,
          session_format: format,
        },
      });
      if (error) throw error;

      alertBox.classList.remove('modal__alert--warning');
      alertBox.classList.add('modal__alert--success');
      alertBox.hidden = false;
      alertMsg.textContent = `Email envoyé à ${email}. Vérifiez la boîte de réception (et les spams).`;
      submitLabel.textContent = 'Envoyer le test';
    } catch (e) {
      alertBox.classList.remove('modal__alert--success');
      alertBox.classList.add('modal__alert--warning');
      alertBox.hidden = false;
      alertMsg.textContent = 'Erreur : ' + (e.message ?? 'inconnue');
      submitLabel.textContent = 'Envoyer le test';
    }
  }

  // ---------------------------------------------------------------------
  // Helpers formatage
  // ---------------------------------------------------------------------

  function escapeHtml(s) {
    if (s === null || s === undefined) return '';
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function formatDateTime(iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    return d.toLocaleDateString('fr-FR', { day: '2-digit', month: 'short' }) +
           ' · ' +
           d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  }

  function formatSessionLabel(isoDate, format) {
    if (!isoDate) return '—';
    const d = new Date(isoDate + 'T12:00:00Z');
    const label = d.toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: '2-digit' });
    return format ? `${label} (${format})` : label;
  }

  // ---------------------------------------------------------------------
  // Démarrage
  // ---------------------------------------------------------------------

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
