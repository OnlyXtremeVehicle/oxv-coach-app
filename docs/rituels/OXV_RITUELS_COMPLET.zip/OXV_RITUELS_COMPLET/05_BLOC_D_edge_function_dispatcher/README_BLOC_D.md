# Bloc D — Edge Function `ritual_dispatcher`

> Code complet de l'orchestrateur qui envoie les rituels J-7, J-2, J-1 aux pilotes OXV.

---

## Structure des fichiers

```
supabase/functions/ritual_dispatcher/
├── index.ts                    # Point d'entrée HTTP, orchestration
├── handlers/
│   ├── jminus7.ts             # Envoi email confirmation + playlist
│   ├── jminus2.ts             # Génération audio + envoi email
│   └── jminus1.ts             # Fetch météo + envoi email
└── lib/
    ├── supabase.ts            # Client DB + Storage + helpers dispatches
    ├── openai.ts              # Appel GPT-4o
    ├── prompt.ts              # System prompt et builder user prompt
    ├── elevenlabs.ts          # Appel Eleven Labs TTS
    ├── resend.ts              # Envoi emails
    ├── weather.ts             # Open-Meteo + mapping FR
    └── templates.ts           # 3 templates HTML embarqués + formatage dates
```

---

## Prérequis avant déploiement

### 1. Bloc A déployé

La migration `migration_rituals.sql` doit avoir été exécutée. Vérifier que :
- La table `public.ritual_dispatches` existe
- Le bucket `audio_briefings` existe
- L'extension `pg_cron` est activée
- Les colonnes opt-in (`ritual_jminus7_enabled`, etc.) existent sur `users`

### 2. Secrets Supabase configurés

```bash
# Depuis la CLI Supabase (à installer si pas déjà fait : npm install -g supabase)
supabase login
supabase link --project-ref fouvuqkdxarjpjbqnsjq

# Définir les secrets
supabase secrets set OPENAI_API_KEY=sk-proj-...
supabase secrets set ELEVENLABS_API_KEY=sk_...
supabase secrets set ELEVENLABS_VOICE_ID=<le_voice_id_choisi>
supabase secrets set RESEND_API_KEY=re_...
supabase secrets set OXV_PLAYLIST_URL=https://open.spotify.com/playlist/...
supabase secrets set EMERGENCY_PHONE_TEL=+33500000000
supabase secrets set EMERGENCY_PHONE_DISPLAY="05 00 00 00 00"

# Vérifier
supabase secrets list
```

### 3. Assets visuels hébergés

Voir Bloc C — fichiers PNG sur `oxvehicle.fr/email-assets/` :
- `insigne-oxv.png`
- `spotify-icon.png`
- `weather-sun.png`, `weather-cloud-sun.png`, `weather-cloud.png`, `weather-rain.png`, `weather-storm.png`

---

## Déploiement

```bash
# Depuis la racine du projet (au-dessus du dossier supabase/)
supabase functions deploy ritual_dispatcher --no-verify-jwt
```

Le flag `--no-verify-jwt` est nécessaire : on gère l'authentification nous-mêmes
via le header Authorization (le service_role est attendu).

**Vérification du déploiement** :

```bash
supabase functions list
# Doit afficher ritual_dispatcher avec status ACTIVE
```

---

## Test manuel

Avant d'attendre que pg_cron déclenche la function, on peut la lancer à la main.

### A) Créer un dispatch de test

Dans le SQL Editor Supabase :

```sql
-- 1) Trouver une registration de test (la vôtre par exemple)
SELECT r.id, u.email, s.session_date
FROM registrations r
JOIN users u ON u.id = r.user_id
JOIN sessions s ON s.id = r.session_id
WHERE u.email = 'votre.email@example.com'
LIMIT 1;

-- 2) Forcer un dispatch immédiat pour test (J-7 par exemple)
INSERT INTO ritual_dispatches
  (registration_id, user_id, session_id, ritual_type, scheduled_for, status)
VALUES
  ('<UUID_REGISTRATION>', '<UUID_USER>', '<UUID_SESSION>', 'jminus7', now() - interval '1 minute', 'pending')
RETURNING id;
```

### B) Appeler l'Edge Function

```bash
curl -X POST \
  https://fouvuqkdxarjpjbqnsjq.supabase.co/functions/v1/ritual_dispatcher \
  -H "Authorization: Bearer <SERVICE_ROLE_KEY>" \
  -H "Content-Type: application/json" \
  -d '{"source": "manual_test"}'
```

**Réponse attendue** :

```json
{
  "processed": 1,
  "sent": 1,
  "skipped": 0,
  "failed": 0,
  "errors": [],
  "duration_ms": 1240
}
```

### C) Vérifier dans Supabase

```sql
-- Le dispatch doit être en status 'sent'
SELECT id, ritual_type, status, sent_at, resend_message_id
FROM ritual_dispatches
WHERE id = '<UUID_DU_DISPATCH>';
```

### D) Vérifier dans Resend

Aller sur https://resend.com/emails — le message doit apparaître avec le tag `ritual_type:jminus7`.

### E) Vérifier votre boîte mail

L'email doit arriver. Si Apple Mail / Gmail, vérifier le rendu visuel.

---

## Tester les 3 rituels

Refaire la procédure pour `jminus2` et `jminus1` :

```sql
INSERT INTO ritual_dispatches
  (registration_id, user_id, session_id, ritual_type, scheduled_for, status)
VALUES
  ('<UUID>', '<UUID>', '<UUID>', 'jminus2', now() - interval '1 minute', 'pending'),
  ('<UUID>', '<UUID>', '<UUID>', 'jminus1', now() - interval '1 minute', 'pending');
```

Puis recurl. Le J-2 prendra 5-10 secondes (génération script + audio).

---

## Surveillance

### Logs en temps réel

```bash
supabase functions logs ritual_dispatcher --tail
```

### Vérifier les dispatches échoués

```sql
SELECT id, ritual_type, last_error, attempt_count
FROM ritual_dispatches
WHERE status = 'failed'
ORDER BY updated_at DESC
LIMIT 20;
```

### Relancer un dispatch échoué

```sql
UPDATE ritual_dispatches
SET status = 'pending', attempt_count = 0, last_error = NULL
WHERE id = '<UUID>';
```

La prochaine exécution de pg_cron (ou un curl manuel) le retraitera.

---

## Limites connues et axes d'amélioration

1. **Timeout 60s** sur plan Supabase Free. Si un audio J-2 prend > 60s à générer
   (script + Eleven Labs + upload + email), la function se coupe et le dispatch
   reste en `generating`. Solution v2 : passer en plan Pro ou découper en
   sub-functions.

2. **Pas de retry automatique**. Décision Bloc D : retry manuel via page admin
   (Bloc E). Si vous voulez du retry auto, ajouter un `if attempt_count < 3 → pending`
   dans `markDispatchFailed`.

3. **Niveau C niveau B fallback**. Le handler J-2 tente de charger `qdi_scores`
   et fallback en B si vide. Si vous voulez forcer un niveau pour test, modifier
   la fonction `loadPilotHistory` dans `handlers/jminus2.ts`.

4. **Pas de webhook Resend**. Pour suivre ouvertures/clics, configurer un webhook
   Resend pointant vers une autre Edge Function (à créer au Bloc E).

5. **Template "no weather"**. Si Open-Meteo down, le template J-1 affiche
   "0°C · Conditions à confirmer", ce qui est imparfait. Améliorer en v2 :
   template dédié sans bloc météo.

---

## Coûts par exécution (estimé)

| Élément | Coût |
|---|---|
| Exécution Edge Function | 0 € (incluse dans plan Free, jusqu'à 500k invocations/mois) |
| Appel OpenAI GPT-4o (J-2 uniquement) | ~0,01 € |
| Appel Eleven Labs (J-2 uniquement) | ~0,15 € |
| Upload Supabase Storage (J-2 uniquement) | 0 € |
| Appel Resend | 0 € (plan Free, sous 3000 emails/mois) |
| Appel Open-Meteo (J-1 uniquement) | 0 € |
| **Total moyen par batch de 3 rituels** | **~0,16 €** |

Sur 32 sessions × 20 pilotes × 3 rituels = 1920 invocations/an → coût ~100€/an
sur Eleven Labs principalement.
