-- =============================================================================
-- OXV — Migration : Système de rituels pré-session (J-7, J-2, J-1)
-- =============================================================================
-- Version       : 1.0
-- Date          : 21 mai 2026
-- Description   : Tables, contraintes, RLS, storage et cron pour orchestrer
--                 les 3 emails/audio de la rampe d'anticipation.
--
-- Prérequis     : Tables users, sessions, registrations, vehicles déjà créées.
--                 Extension pg_cron activée (Supabase Dashboard > Database
--                 > Extensions > pg_cron).
--                 Extension pg_net activée pour appeler les Edge Functions
--                 depuis pg_cron (Database > Extensions > pg_net).
-- =============================================================================


-- =============================================================================
-- 1. EXTENSIONS REQUISES
-- =============================================================================

-- pg_cron pour le déclencheur quotidien (à activer manuellement dans le dashboard
-- si pas déjà fait : Database > Extensions > pg_cron)
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- pg_net pour appeler les Edge Functions HTTPS depuis pg_cron
CREATE EXTENSION IF NOT EXISTS pg_net;


-- =============================================================================
-- 2. TYPE ENUM POUR LES TYPES DE RITUEL
-- =============================================================================

DO $$ BEGIN
  CREATE TYPE ritual_type_enum AS ENUM ('jminus7', 'jminus2', 'jminus1');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE TYPE ritual_status_enum AS ENUM (
    'pending',      -- planifié, pas encore traité
    'generating',   -- en cours de génération (LLM ou TTS)
    'sent',         -- envoyé avec succès
    'failed',       -- échec, à investiguer
    'skipped'       -- volontairement ignoré (ex. pilote a opt-out, session annulée)
  );
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;


-- =============================================================================
-- 3. TABLE PRINCIPALE : ritual_dispatches
-- =============================================================================

CREATE TABLE IF NOT EXISTS public.ritual_dispatches (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Liens vers les entités métier
  registration_id     uuid NOT NULL REFERENCES public.registrations(id) ON DELETE CASCADE,
  user_id             uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  session_id          uuid NOT NULL REFERENCES public.sessions(id) ON DELETE CASCADE,

  -- Type et état
  ritual_type         ritual_type_enum NOT NULL,
  status              ritual_status_enum NOT NULL DEFAULT 'pending',

  -- Planification
  scheduled_for       timestamptz NOT NULL,   -- quand l'envoi doit avoir lieu
  sent_at             timestamptz,            -- quand il a effectivement été envoyé

  -- Contenu généré (archivage + debug)
  payload             jsonb,                  -- script audio, météo, variables, etc.
  audio_storage_path  text,                   -- chemin Supabase Storage si J-2
  audio_duration_sec  integer,                -- durée du MP3 généré

  -- Suivi prestataires
  resend_message_id   text,                   -- ID Resend pour tracking ouvertures/clics
  openai_tokens_used  integer,                -- coût LLM
  elevenlabs_chars    integer,                -- caractères TTS facturés

  -- Gestion des erreurs et retries
  attempt_count       integer NOT NULL DEFAULT 0,
  last_error          text,                   -- dernier message d'erreur si failed
  last_attempt_at     timestamptz,

  -- Audit
  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now(),

  -- Contrainte d'idempotence : un seul dispatch par (registration, type)
  CONSTRAINT ritual_dispatches_unique_per_registration
    UNIQUE (registration_id, ritual_type)
);

-- Index pour les requêtes du dispatcher (cherche les "pending" dont scheduled_for <= now())
CREATE INDEX IF NOT EXISTS idx_ritual_dispatches_pending_scheduled
  ON public.ritual_dispatches (status, scheduled_for)
  WHERE status = 'pending';

-- Index pour la page admin de monitoring (filtrer par utilisateur, par session)
CREATE INDEX IF NOT EXISTS idx_ritual_dispatches_user
  ON public.ritual_dispatches (user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_ritual_dispatches_session
  ON public.ritual_dispatches (session_id, ritual_type);

-- Trigger updated_at automatique
CREATE OR REPLACE FUNCTION public.ritual_dispatches_set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_ritual_dispatches_updated_at ON public.ritual_dispatches;
CREATE TRIGGER trg_ritual_dispatches_updated_at
  BEFORE UPDATE ON public.ritual_dispatches
  FOR EACH ROW
  EXECUTE FUNCTION public.ritual_dispatches_set_updated_at();


-- =============================================================================
-- 4. RLS — Row Level Security
-- =============================================================================
-- Politique : les pilotes voient leurs propres dispatches (lecture seule).
-- Les admins voient tout. Aucune insertion/modification depuis le client.
-- L'Edge Function utilise le service_role qui bypasse RLS.

ALTER TABLE public.ritual_dispatches ENABLE ROW LEVEL SECURITY;

-- Pilote lit ses propres dispatches
DROP POLICY IF EXISTS ritual_dispatches_select_own ON public.ritual_dispatches;
CREATE POLICY ritual_dispatches_select_own
  ON public.ritual_dispatches
  FOR SELECT
  USING (auth.uid() = user_id);

-- Admin lit tout (via fonction is_admin déjà définie dans le projet)
DROP POLICY IF EXISTS ritual_dispatches_select_admin ON public.ritual_dispatches;
CREATE POLICY ritual_dispatches_select_admin
  ON public.ritual_dispatches
  FOR SELECT
  USING (public.is_admin());

-- Aucune INSERT/UPDATE/DELETE depuis le client.
-- L'Edge Function passe par service_role qui contourne RLS.


-- =============================================================================
-- 5. PRÉFÉRENCES UTILISATEUR — Opt-in / opt-out par rituel
-- =============================================================================
-- Le pilote doit pouvoir désactiver un rituel spécifique (par ex. ne pas vouloir
-- l'audio). On ajoute des colonnes à la table preferences existante si elle
-- existe, sinon on crée des colonnes sur users.

-- Si vous avez déjà une table user_preferences :
--   ALTER TABLE public.user_preferences
--     ADD COLUMN IF NOT EXISTS ritual_jminus7_enabled boolean NOT NULL DEFAULT true,
--     ADD COLUMN IF NOT EXISTS ritual_jminus2_enabled boolean NOT NULL DEFAULT true,
--     ADD COLUMN IF NOT EXISTS ritual_jminus1_enabled boolean NOT NULL DEFAULT true;

-- Sinon, sur users directement (ajustez selon votre schéma actuel) :
ALTER TABLE public.users
  ADD COLUMN IF NOT EXISTS ritual_jminus7_enabled boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS ritual_jminus2_enabled boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS ritual_jminus1_enabled boolean NOT NULL DEFAULT true;


-- =============================================================================
-- 6. BUCKET SUPABASE STORAGE pour les audios J-2
-- =============================================================================
-- À exécuter dans le SQL Editor. Si déjà créé manuellement via le dashboard,
-- cette section est idempotente.

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'audio_briefings',
  'audio_briefings',
  false,                          -- privé, accès via URL signée uniquement
  10485760,                       -- 10 MB max par fichier (largement suffisant pour 2 min MP3)
  ARRAY['audio/mpeg', 'audio/mp3']
)
ON CONFLICT (id) DO NOTHING;

-- Politique : seul le service_role peut écrire ; les utilisateurs lisent via URL signée
-- générée par l'Edge Function. Pas de lecture directe depuis le client.

DROP POLICY IF EXISTS audio_briefings_no_public_access ON storage.objects;
CREATE POLICY audio_briefings_no_public_access
  ON storage.objects
  FOR ALL
  USING (bucket_id = 'audio_briefings' AND false);  -- bloque tout sauf service_role


-- =============================================================================
-- 7. FONCTION DE PLANIFICATION — appelée à la confirmation d'inscription
-- =============================================================================
-- À appeler depuis l'admin quand une registration passe à 'confirmed' (paiement OK).
-- Crée les 3 lignes de ritual_dispatches en statut 'pending'.

CREATE OR REPLACE FUNCTION public.schedule_rituals_for_registration(
  p_registration_id uuid
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_user_id     uuid;
  v_session_id  uuid;
  v_session_date date;
BEGIN
  -- Récupérer les infos de la registration
  SELECT r.user_id, r.session_id, s.session_date
    INTO v_user_id, v_session_id, v_session_date
  FROM public.registrations r
  JOIN public.sessions s ON s.id = r.session_id
  WHERE r.id = p_registration_id;

  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Registration % introuvable', p_registration_id;
  END IF;

  -- Insérer les 3 rituels en 'pending' avec leur scheduled_for à 18h00 locale.
  -- Le ON CONFLICT garantit l'idempotence (si on rappelle la fonction, pas de doublon).

  INSERT INTO public.ritual_dispatches
    (registration_id, user_id, session_id, ritual_type, scheduled_for)
  VALUES
    (p_registration_id, v_user_id, v_session_id, 'jminus7',
     (v_session_date - INTERVAL '7 days' + INTERVAL '18 hours')::timestamptz AT TIME ZONE 'Europe/Paris'),
    (p_registration_id, v_user_id, v_session_id, 'jminus2',
     (v_session_date - INTERVAL '2 days' + INTERVAL '18 hours')::timestamptz AT TIME ZONE 'Europe/Paris'),
    (p_registration_id, v_user_id, v_session_id, 'jminus1',
     (v_session_date - INTERVAL '1 day' + INTERVAL '18 hours')::timestamptz AT TIME ZONE 'Europe/Paris')
  ON CONFLICT (registration_id, ritual_type) DO NOTHING;
END;
$$;


-- =============================================================================
-- 8. FONCTION D'ANNULATION — appelée si registration annulée ou session annulée
-- =============================================================================

CREATE OR REPLACE FUNCTION public.cancel_pending_rituals_for_registration(
  p_registration_id uuid
)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_count integer;
BEGIN
  UPDATE public.ritual_dispatches
     SET status = 'skipped',
         last_error = 'Registration cancelled'
   WHERE registration_id = p_registration_id
     AND status = 'pending';

  GET DIAGNOSTICS v_count = ROW_COUNT;
  RETURN v_count;
END;
$$;


-- =============================================================================
-- 9. CRON — Déclencheur quotidien
-- =============================================================================
-- Tourne tous les jours à 18h00 heure de Paris (= 16h00 UTC en été, 17h00 UTC en hiver).
-- Pour éviter le casse-tête saison été/hiver, on tourne deux fois et on laisse
-- l'Edge Function filtrer les dispatches dont scheduled_for <= now().
-- Plus simple : on lance toutes les heures de 16h à 18h UTC, l'Edge Function
-- est idempotente (elle ne traite que les 'pending').
--
-- ATTENTION : remplacez {{SUPABASE_PROJECT_REF}} et {{SUPABASE_SERVICE_ROLE_KEY}}
-- par les vraies valeurs avant d'exécuter, OU utilisez vault.read_secret() si
-- vous avez configuré Supabase Vault pour stocker la clé service_role.

-- Désinscrire un job existant s'il existe (idempotent)
SELECT cron.unschedule('ritual_dispatcher_hourly')
WHERE EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'ritual_dispatcher_hourly');

-- Planifier l'appel : toutes les heures entre 16h et 19h UTC (couvre 17h-21h Paris)
SELECT cron.schedule(
  'ritual_dispatcher_hourly',
  '0 16-19 * * *',  -- minute 0, heures 16 à 19 UTC, tous les jours
  $$
  SELECT net.http_post(
    url := 'https://{{SUPABASE_PROJECT_REF}}.supabase.co/functions/v1/ritual_dispatcher',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer {{SUPABASE_SERVICE_ROLE_KEY}}'
    ),
    body := jsonb_build_object('source', 'pg_cron')
  );
  $$
);


-- =============================================================================
-- 10. VUE D'ADMIN — pour la page de monitoring (Bloc E)
-- =============================================================================
-- Vue dénormalisée qui joint les infos utiles pour l'écran admin.

CREATE OR REPLACE VIEW public.admin_ritual_dispatches_view AS
SELECT
  rd.id,
  rd.ritual_type,
  rd.status,
  rd.scheduled_for,
  rd.sent_at,
  rd.attempt_count,
  rd.last_error,
  rd.audio_storage_path,
  rd.audio_duration_sec,
  rd.resend_message_id,
  rd.created_at,
  rd.updated_at,

  -- Pilote
  u.id              AS user_id,
  u.first_name      AS pilot_first_name,
  u.last_name       AS pilot_last_name,
  u.email           AS pilot_email,

  -- Session
  s.id              AS session_id,
  s.session_date    AS session_date,
  s.session_format  AS session_format,

  -- Registration
  r.id              AS registration_id,
  r.tier            AS registration_tier
FROM public.ritual_dispatches rd
JOIN public.users         u ON u.id = rd.user_id
JOIN public.sessions      s ON s.id = rd.session_id
JOIN public.registrations r ON r.id = rd.registration_id;

-- Accès admin seulement
ALTER VIEW public.admin_ritual_dispatches_view OWNER TO postgres;


-- =============================================================================
-- FIN DE LA MIGRATION
-- =============================================================================
-- Vérifications post-migration recommandées :
--
-- 1) Tester l'idempotence :
--    SELECT public.schedule_rituals_for_registration('<un_uuid_de_test>');
--    SELECT public.schedule_rituals_for_registration('<le_meme_uuid>'); -- doit ne rien insérer
--    SELECT * FROM ritual_dispatches WHERE registration_id = '<uuid>';
--
-- 2) Vérifier le cron :
--    SELECT * FROM cron.job WHERE jobname = 'ritual_dispatcher_hourly';
--
-- 3) Vérifier le bucket :
--    SELECT * FROM storage.buckets WHERE id = 'audio_briefings';
--
-- 4) Vérifier les RLS :
--    SELECT polname, polcmd FROM pg_policy
--    WHERE polrelid = 'public.ritual_dispatches'::regclass;
-- =============================================================================
