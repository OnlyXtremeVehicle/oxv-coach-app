# 🏁 OXV — Système de rituels pré-session

> **Guide maître de mise en place complète**
> **Du Bloc A au Bloc E, en 21 étapes ordonnées**
> Version : 1.0 · 22 mai 2026

---

## Préambule

Ce dossier contient **l'intégralité du système OXV de rituels pré-session** conçu lors de notre session de travail. Le système envoie automatiquement trois messages à chaque pilote inscrit à une session : un email J-7 (confirmation + playlist), un audio personnalisé J-2 (briefing voix IA), et un email J-1 (rappel + météo).

Le tout fonctionne sans intervention manuelle une fois déployé : pg_cron déclenche, l'Edge Function dispatche, GPT-4o écrit, Eleven Labs lit, Resend envoie, Open-Meteo informe. La page admin permet de tout monitorer.

---

## 📁 Structure du livrable

```
OXV_RITUELS_COMPLET/
├── 01_GUIDE/                                 ← Vous êtes ici
│   └── GUIDE_MAITRE.md
│
├── 02_BLOC_A_database/
│   └── migration_rituals.sql                 (tables, RLS, cron, fonctions)
│
├── 03_BLOC_B_prompt_voix/
│   └── ritual_audio_prompt.ts                (system prompt GPT-4o + voix EL)
│
├── 04_BLOC_C_templates_emails/
│   ├── email_jminus7.html                    (template J-7)
│   ├── email_jminus2.html                    (template J-2)
│   └── email_jminus1.html                    (template J-1)
│
├── 05_BLOC_D_edge_function_dispatcher/
│   ├── README_BLOC_D.md
│   └── supabase/functions/ritual_dispatcher/
│       ├── index.ts                          (orchestrateur HTTP)
│       ├── handlers/                         (1 fichier par rituel)
│       └── lib/                              (7 librairies)
│
├── 06_BLOC_E_admin_monitoring/
│   ├── README_BLOC_E.md
│   ├── migration_rituals_bloc_e.sql          (tracking + stats)
│   ├── admin-rituels.html                    (markup page admin)
│   ├── admin-rituels.css                     (styles)
│   ├── admin-rituels.js                      (logique JS)
│   └── supabase/functions/
│       ├── resend_webhook/index.ts           (réception events Resend)
│       └── ritual_dryrun/index.ts            (envois test)
│
└── 99_ASSETS/
    └── insigne_OXV_reference.png             (insigne à optimiser pour emails)
```

---

## 🎯 Vue d'ensemble — Les 5 Blocs

| Bloc | Quoi | Effort déploiement | Coût |
|---|---|---|---|
| **A** | Schéma Supabase : tables, RLS, cron, bucket | 30 min | 0 € |
| **B** | Comptes API + voix Eleven Labs choisie + test prompt | 2-3 h | 22 €/mois (EL) |
| **C** | Templates HTML emails + assets PNG + playlist Spotify | 3-4 h | 0 € |
| **D** | Edge Function `ritual_dispatcher` déployée | 1 h | ~5 €/an (OpenAI) |
| **E** | Page admin + webhook + dryrun déployés | 2-3 h | 0 € |
| **TOTAL** | Système complet opérationnel | **~10 h sur 3-5 jours** | **~270 €/an** |

---

## ⏱️ Chronologie recommandée

Si vous voulez tout déployer en parallèle d'autres tâches, voici le planning idéal sur **5 jours ouvrés** :

```
Jour 1 (matin)    : Étapes 1-4   — Création comptes OpenAI/Eleven Labs/Resend
                                    + lancement DNS OVH (propagation en parallèle)

Jour 1 (après-m.) : Étapes 5-6   — Choix voix Eleven Labs + secrets Supabase

Jour 2 (matin)    : Étapes 7-9   — Exécution migrations SQL A et E

Jour 2 (après-m.) : Étape 10     — Test du prompt GPT-4o au Playground

Jour 3            : Étapes 11-13 — Production assets (insigne, météo, Spotify)
                                    + playlist Spotify (le plus chronophage)

Jour 4 (matin)    : Étapes 14-16 — Test templates Resend dans Resend Dashboard

Jour 4 (après-m.) : Étapes 17-18 — Déploiement Edge Functions + tests curl

Jour 5            : Étapes 19-21 — Intégration page admin + webhook + tests E2E
```

---

# 📋 LES 21 ÉTAPES DE MISE EN PLACE

Chaque étape a sa **case à cocher**. Suivre dans l'ordre.

---

## PHASE 1 — PRÉREQUIS COMPTES ET SERVICES

### ☐ Étape 1 — Créer le compte OpenAI

1. Aller sur https://platform.openai.com
2. Créer un compte ou se connecter
3. **API keys** → **Create new secret key** → nommer `oxv-production-ritual-dispatcher`
4. Copier la clé (commence par `sk-proj-...`) — elle ne sera plus jamais affichée
5. **Billing** → ajouter une carte
6. **Usage limits** → définir une limite mensuelle à 20 € (besoin réel ~1 €/mois)
7. **Activer les notifications** à 5/10/15 €

**Coût** : ~5 €/an pour 640 audios.
**Clé à conserver dans un gestionnaire de mots de passe**.

---

### ☐ Étape 2 — Créer le compte Eleven Labs

1. Aller sur https://elevenlabs.io
2. Souscrire au **plan Creator** ($22/mois) — donne 100 000 caractères/mois
3. **Profile** → **API Key** → copier (format `sk_...`)
4. Ne pas encore choisir la voix — voir Étape 5

**Coût** : 264 €/an. C'est le poste principal du système.

---

### ☐ Étape 3 — Créer le compte Resend et configurer DNS

1. Aller sur https://resend.com
2. Créer un compte (plan **Free** suffit — 3 000 emails/mois, vos besoins ~60/mois)
3. **Domains** → **Add domain** → `oxvehicle.fr`
4. Resend génère **4 enregistrements DNS** (SPF, DKIM, DMARC, Return-Path)
5. **Configuration chez OVH** :
   - https://www.ovh.com/manager/ → **Domaines** → `oxvehicle.fr` → **Zone DNS**
   - Ajouter les 4 enregistrements (un par un)
6. **Lancer la propagation** — temps : 15 min à 4 h selon TTL
7. Pendant la propagation, faire les étapes suivantes
8. Revenir sur Resend → **Verify DNS** sur chaque enregistrement → tous doivent passer en vert ✅
9. **API Keys** → **Create API Key** → nom `oxv-production`, permissions **Full access** → copier (format `re_...`)

**Coût** : 0 € (plan Free).

---

### ☐ Étape 4 — Configurer Supabase

Votre projet Supabase `fouvuqkdxarjpjbqnsjq` est déjà actif. À faire :

1. **Database → Extensions** → activer :
   - ✅ `pg_cron`
   - ✅ `pg_net`
2. **Settings → API** → noter :
   - URL : `https://fouvuqkdxarjpjbqnsjq.supabase.co`
   - Clé **service_role** (commence par `eyJ...`) — **NE JAMAIS exposer côté client**

---

## PHASE 2 — CHOIX DE LA VOIX

### ☐ Étape 5 — Tester et choisir la voix Eleven Labs

1. Dashboard Eleven Labs → **Voice Library**
2. Filtrer par **French** OU activer **Multilingual v2**
3. Identifier 3-4 voix masculines candidates :
   - Voix grave (registre baryton, pas ténor)
   - Posée (rythme < 160 mots/min)
   - Sans accent prononcé
   - Pas "speakerine"

**Paragraphe de test** (copier dans le testeur Eleven Labs avec chaque voix) :

> Bonjour Gabin. Dans deux jours, vous roulerez à La Génétouze. Le circuit que vous allez découvrir a été dessiné par Jean-Pierre Beltoise. Deux kilomètres six. Quatorze virages. Une enchaînée qui ressemble à Magny-Cours et une épingle qui ne ressemble à rien d'autre. Vous prendrez le temps de la lire, pas de la combattre.

**Paramètres de test** :
- Model : `Eleven Multilingual v2`
- Stability : `0.55`
- Similarity Boost : `0.75`
- Style : `0.0`
- Speaker Boost : ON

**À écouter au casque, impérativement.**

4. Une fois la voix choisie : **Voices** → cliquer dessus → copier le **Voice ID** (format `pNInz6obpgDQGcFmaJgB`)

**Voice ID définitif à noter** : `___________________________`

---

### ☐ Étape 6 — Stocker tous les secrets dans Supabase

Installer la CLI Supabase si pas déjà fait :
```bash
npm install -g supabase
```

Puis se connecter :
```bash
supabase login
supabase link --project-ref fouvuqkdxarjpjbqnsjq
```

Définir les secrets :
```bash
supabase secrets set OPENAI_API_KEY=sk-proj-...
supabase secrets set ELEVENLABS_API_KEY=sk_...
supabase secrets set ELEVENLABS_VOICE_ID=<voice_id_choisi_étape_5>
supabase secrets set RESEND_API_KEY=re_...
supabase secrets set OXV_PLAYLIST_URL=https://open.spotify.com/playlist/REPLACE_ME
supabase secrets set EMERGENCY_PHONE_TEL=+33500000000
supabase secrets set EMERGENCY_PHONE_DISPLAY="05 00 00 00 00"
# RESEND_WEBHOOK_SECRET sera ajouté à l'étape 20

# Vérifier
supabase secrets list
```

---

## PHASE 3 — MIGRATIONS BASE DE DONNÉES

### ☐ Étape 7 — Vérifier le schéma de vos tables existantes

Avant la migration, vérifier les noms de colonnes (j'ai supposé certains noms qui peuvent différer chez vous).

Dans le **SQL Editor Supabase** :

```sql
SELECT column_name, data_type
FROM information_schema.columns
WHERE table_schema = 'public'
  AND table_name IN ('users', 'sessions', 'registrations', 'vehicles')
ORDER BY table_name, ordinal_position;
```

**Colonnes attendues par le code** :

| Table | Colonnes |
|---|---|
| `users` | `id`, `first_name`, `last_name`, `email` |
| `sessions` | `id`, `session_date`, `session_format` |
| `registrations` | `id`, `user_id`, `session_id`, `vehicle_id`, `ref`, `tier` |
| `vehicles` | `id`, `make`, `model`, `year` |

**Si des noms diffèrent** : noter les différences pour adapter `02_BLOC_A_database/migration_rituals.sql` ET le code TypeScript de `05_BLOC_D_edge_function_dispatcher/supabase/functions/ritual_dispatcher/lib/supabase.ts`.

---

### ☐ Étape 8 — Exécuter la migration du Bloc A

1. Ouvrir `02_BLOC_A_database/migration_rituals.sql`
2. **AVANT d'exécuter**, remplacer dans la section CRON :
   - `{{SUPABASE_PROJECT_REF}}` → `fouvuqkdxarjpjbqnsjq`
   - `{{SUPABASE_SERVICE_ROLE_KEY}}` → votre vraie clé service_role
3. Coller le contenu complet dans le SQL Editor Supabase
4. **Run** (Cmd+Enter)
5. Vérifier qu'aucune erreur n'apparaît

**Vérifications post-migration** (à exécuter une par une dans le SQL Editor) :

```sql
-- 1) La table existe
SELECT column_name FROM information_schema.columns
WHERE table_schema = 'public' AND table_name = 'ritual_dispatches';
-- Attendu : 17 colonnes

-- 2) Le bucket existe
SELECT id, public FROM storage.buckets WHERE id = 'audio_briefings';
-- Attendu : 1 ligne, public = false

-- 3) Le cron est planifié
SELECT jobname, schedule FROM cron.job WHERE jobname = 'ritual_dispatcher_hourly';
-- Attendu : 1 ligne, schedule = '0 16-19 * * *'

-- 4) Les RLS sont en place
SELECT polname FROM pg_policy WHERE polrelid = 'public.ritual_dispatches'::regclass;
-- Attendu : 2 lignes (select_own + select_admin)
```

**Test fonctionnel** :

```sql
-- Prendre une registration existante
SELECT id FROM public.registrations LIMIT 1;
-- Copier l'UUID

-- Planifier les 3 rituels
SELECT public.schedule_rituals_for_registration('<UUID>');

-- Vérifier
SELECT ritual_type, status, scheduled_for FROM public.ritual_dispatches
WHERE registration_id = '<UUID>';
-- Attendu : 3 lignes en 'pending'

-- Tester l'idempotence (ne doit créer aucun doublon)
SELECT public.schedule_rituals_for_registration('<UUID>');
SELECT count(*) FROM public.ritual_dispatches WHERE registration_id = '<UUID>';
-- Attendu : 3 (toujours)

-- Nettoyer
DELETE FROM public.ritual_dispatches WHERE registration_id = '<UUID>';
```

---

### ☐ Étape 9 — Exécuter la migration du Bloc E

1. Ouvrir `06_BLOC_E_admin_monitoring/migration_rituals_bloc_e.sql`
2. Coller dans le SQL Editor Supabase
3. **Run**

**Vérifications** :

```sql
-- Nouvelles colonnes
SELECT column_name FROM information_schema.columns
WHERE table_name = 'ritual_dispatches'
  AND column_name IN ('delivered_at', 'opened_at', 'clicked_at', 'bounced_at');
-- Attendu : 4 lignes

-- Table resend_events
SELECT count(*) FROM public.resend_events;
-- Attendu : 0

-- Fonction stats
SELECT public.admin_ritual_stats(30);
-- Attendu : JSON avec compteurs à 0
```

---

## PHASE 4 — VALIDATION DU PROMPT GPT-4O

### ☐ Étape 10 — Tester le prompt au Playground OpenAI

Avant de déployer, valider manuellement que le prompt produit du contenu OXV-compatible.

1. Aller sur https://platform.openai.com/playground/chat
2. Configurer :
   - Model : `gpt-4o`
   - Temperature : `0.7`
   - Response format : `json_object`
3. **System message** : copier le `SYSTEM_PROMPT` complet depuis `03_BLOC_B_prompt_voix/ritual_audio_prompt.ts`
4. **User message** : coller cet exemple :

```
# Génère le script audio pour la session suivante

## Pilote
- Prénom : Gabin
- Numéro de session OXV : 1 (PREMIÈRE session, mentionne-le subtilement)

## Session à venir
- Date : mardi 9 juin
- Format : Access
- Jours restants : 2

## Véhicule du pilote
- Marque : Porsche
- Modèle : 911 GT3
- Année : 2024

## Niveau de personnalisation demandé
B

## Aucune donnée historique
Tu écris en niveau B : générique-mais-personnel, basé uniquement sur prénom + voiture + palier.

# Maintenant, génère le JSON de sortie.
```

5. **Run**

**Grille de validation** (toutes les cases doivent être ✅) :

- ☐ Le script fait entre 220 et 260 mots
- ☐ Structure voiture → rythme → briefing respectée
- ☐ Aucune formule commerciale ("ravi", "incroyable", "n'hésitez pas")
- ☐ Aucun point d'exclamation
- ☐ Vouvoiement systématique
- ☐ Prénom uniquement en intro et clôture
- ☐ Pas de chiffres de météo
- ☐ Ton sec et posé, pas vendeur

**Tester sur 3 profils** : première session voiture grand public, première session voiture rare, niveau C avec historique fictif.

Si un critère échoue : durcir le system prompt, retester.

---

## PHASE 5 — ASSETS VISUELS ET PLAYLIST

### ☐ Étape 11 — Optimiser l'insigne OXV

Le fichier `99_ASSETS/insigne_OXV_reference.png` est la version 512×512 de votre favicon. À optimiser pour les emails.

**Cahier des charges** :
- Nom : `insigne-oxv.png`
- Dimensions : **192 × 210 px** (ratio preservé pour rendu 64 × 70 retina)
- Format : PNG-24 avec transparence
- Poids : < 30 Ko
- Couleur fond : transparente
- Couleur insigne : rouge `#C8102E`

**Procédure** :
1. Ouvrir l'original dans Photoshop / Affinity / Photopea (https://www.photopea.com gratuit en ligne)
2. Redimensionner à 192 × 210 avec ratio préservé
3. Exporter PNG-24 avec transparence
4. Compresser sur https://tinypng.com
5. Vérifier le poids < 30 Ko

---

### ☐ Étape 12 — Créer les icônes météo

Vous avez besoin de **5 icônes** pour les conditions météo principales :

| Slug | Condition |
|---|---|
| `sun` | Ciel dégagé |
| `cloud-sun` | Soleil voilé |
| `cloud` | Couvert |
| `rain` | Pluie |
| `storm` | Orages |

**Cahier des charges** :
- 80 × 80 px (rendu 40 × 40 retina)
- PNG-24 transparent
- Couleur : rouge OXV `#C8102E` (pour `sun`) ou gris foncé `#4A4A4A` pour les autres

**Source recommandée** : Lucide Icons (https://lucide.dev) — libre de droits, design sobre cohérent avec OXV. Exporter chaque icône en SVG, recolorer, exporter PNG 80 × 80.

---

### ☐ Étape 13 — Curer la playlist Spotify et héberger les assets

#### A) Créer la playlist Spotify

1. Compte Spotify professionnel au nom de la marque
2. **Nouvelle playlist** : "OXV — Saison 2026"
3. Description : *"Trente titres pour habiter la semaine. La route vers le circuit, le casque avant le départ, le retour le soir."*
4. Cover image : visuel 640 × 640 avec l'insigne OXV sur fond noir
5. Définir comme **publique**
6. Ajouter 30 titres curatés (ambient, post-rock, électronique sombre, jazz tendu… pas de pop grand public)
7. Copier l'URL publique (format `https://open.spotify.com/playlist/XXXXXX`)

**Mettre à jour le secret Supabase** :
```bash
supabase secrets set OXV_PLAYLIST_URL=https://open.spotify.com/playlist/<vraie_url>
```

#### B) Récupérer l'icône Spotify officielle

1. https://newsroom.spotify.com/media-kit/logo-and-brand-assets/
2. Télécharger le logo **monochrome blanc**
3. Redimensionner à 48 × 48 px, exporter PNG
4. Nommer `spotify-icon.png`

#### C) Héberger tous les assets sur `oxvehicle.fr/email-assets/`

Vous avez choisi **Solution 1 — Dossier `public/email-assets/` dans le repo**.

1. Dans votre repo GitHub `OnlyXtremeVehicle/oxv-site`, créer le dossier `email-assets/` à la racine
2. Y déposer **7 fichiers** :
   - `insigne-oxv.png`
   - `spotify-icon.png`
   - `weather-sun.png`
   - `weather-cloud-sun.png`
   - `weather-cloud.png`
   - `weather-rain.png`
   - `weather-storm.png`
3. Commit + push
4. Vercel redéploie automatiquement
5. **Tester chaque URL** dans un navigateur :
   - `https://oxvehicle.fr/email-assets/insigne-oxv.png` doit afficher l'image
   - Idem pour les 6 autres

---

## PHASE 6 — TESTS VISUELS DES TEMPLATES

### ☐ Étape 14 — Tester l'email J-7

1. Aller sur https://resend.com/emails → **Send Email**
2. **From** : `OXV <contact@oxvehicle.fr>`
3. **To** : votre email personnel
4. **Subject** : `Mardi 9 juin · La Génétouze`
5. **HTML** : coller `04_BLOC_C_templates_emails/email_jminus7.html`
6. **AVANT D'ENVOYER**, remplacer manuellement les variables `{{xxx}}` par des valeurs réelles :
   - `{{pilot_first_name}}` → `Gabin`
   - `{{session_date_short}}` → `9 juin`
   - `{{session_date_full}}` → `Mardi 9 juin 2026`
   - `{{vehicle_make}}` → `Porsche`
   - `{{vehicle_model}}` → `911 GT3`
   - `{{session_format}}` → `Access`
   - `{{playlist_spotify_url}}` → l'URL Spotify de l'étape 13
   - `{{registration_ref}}` → `OXV-A4F92B11`
7. **Send**

**Grille de validation visuelle** (sur 4 clients mail) :

|  | Apple Mail | Gmail web | Outlook | iPhone Mail |
|---|---|---|---|---|
| Insigne s'affiche | ☐ | ☐ | ☐ | ☐ |
| Filet rouge `#C8102E` visible | ☐ | ☐ | ☐ | ☐ |
| Polices Georgia | ☐ | ☐ | ⚠️ Times OK | ☐ |
| Pas de débordement | ☐ | ☐ | ☐ | ☐ |
| Bouton "Écouter" cliquable | ☐ | ☐ | ☐ | ☐ |
| Préheader dans l'aperçu inbox | ☐ | ☐ | n/a | ☐ |

---

### ☐ Étape 15 — Tester l'email J-2

Même procédure avec `email_jminus2.html`. Variables à remplir :
- `{{pilot_first_name}}` → `Gabin`
- `{{session_day_name}}` → `mardi`
- `{{audio_duration_label}}` → `1 MIN 28`
- `{{audio_url}}` → mettre un MP3 de test, ou un placeholder
- `{{registration_ref}}` → `OXV-A4F92B11`

---

### ☐ Étape 16 — Tester l'email J-1

Avec `email_jminus1.html`. Variables :
- `{{pilot_first_name}}` → `Gabin`
- `{{weather_summary}}` → `Ciel dégagé. 19 degrés.`
- `{{weather_icon_slug}}` → `sun`
- `{{weather_label}}` → `Ciel dégagé`
- `{{temperature_celsius}}` → `19`
- `{{wind_kmh}}` → `8`
- `{{ground_condition}}` → `sol sec`
- `{{tire_recommendation}}` → `Le ciel sera dégagé. Pneus de route adaptés, pas besoin de pluie.`
- `{{emergency_phone_tel}}` → `+33500000000`
- `{{emergency_phone_display}}` → `05 00 00 00 00`
- `{{registration_ref}}` → `OXV-A4F92B11`

---

## PHASE 7 — DÉPLOIEMENT DES EDGE FUNCTIONS

### ☐ Étape 17 — Déployer `ritual_dispatcher` (Bloc D)

1. Naviguer dans le dossier `05_BLOC_D_edge_function_dispatcher/`
2. Copier l'arborescence `supabase/functions/ritual_dispatcher/` à la racine de votre projet local (au-dessus du dossier où vous avez le repo)
3. Déployer :
   ```bash
   supabase functions deploy ritual_dispatcher --no-verify-jwt
   ```
4. Vérifier :
   ```bash
   supabase functions list
   # Doit afficher ritual_dispatcher avec status ACTIVE
   ```

**Test manuel** :

```sql
-- Créer un dispatch de test (votre propre email)
INSERT INTO ritual_dispatches
  (registration_id, user_id, session_id, ritual_type, scheduled_for, status)
VALUES
  ('<UUID_registration>', '<UUID_user>', '<UUID_session>', 'jminus7', now() - interval '1 min', 'pending')
RETURNING id;
```

```bash
curl -X POST \
  https://fouvuqkdxarjpjbqnsjq.supabase.co/functions/v1/ritual_dispatcher \
  -H "Authorization: Bearer <SERVICE_ROLE_KEY>" \
  -H "Content-Type: application/json" \
  -d '{"source": "manual_test"}'
```

Réponse attendue :
```json
{ "processed": 1, "sent": 1, "skipped": 0, "failed": 0, "errors": [], "duration_ms": 1240 }
```

L'email doit arriver dans votre boîte en quelques secondes.

**Refaire pour J-2 et J-1** (le J-2 prendra 5-10 s à cause de GPT-4o + Eleven Labs).

---

### ☐ Étape 18 — Déployer `resend_webhook` et `ritual_dryrun` (Bloc E)

1. Copier les 2 dossiers `supabase/functions/resend_webhook/` et `supabase/functions/ritual_dryrun/` à la racine
2. Déployer :
   ```bash
   supabase functions deploy resend_webhook --no-verify-jwt
   supabase functions deploy ritual_dryrun --no-verify-jwt
   ```
3. Vérifier que les 3 functions sont actives :
   ```bash
   supabase functions list
   ```

---

## PHASE 8 — WEBHOOK RESEND ET PAGE ADMIN

### ☐ Étape 19 — Configurer le webhook Resend

1. Dashboard Resend → **Webhooks** → **Add Endpoint**
2. **URL** : `https://fouvuqkdxarjpjbqnsjq.supabase.co/functions/v1/resend_webhook`
3. **Events à activer** :
   - ✅ `email.sent`
   - ✅ `email.delivered`
   - ✅ `email.delivery_delayed`
   - ✅ `email.bounced`
   - ✅ `email.opened`
   - ✅ `email.clicked`
   - ✅ `email.complained`
4. **Create** → Resend génère un **Signing Secret**
5. Copier le secret et le stocker :
   ```bash
   supabase secrets set RESEND_WEBHOOK_SECRET=whsec_...
   ```

**Test du webhook** :
- Resend Dashboard → **Send test event**
- Vérifier les logs :
  ```bash
  supabase functions logs resend_webhook --tail
  ```
- Vérifier en SQL :
  ```sql
  SELECT * FROM resend_events ORDER BY processed_at DESC LIMIT 5;
  ```

---

### ☐ Étape 20 — Intégrer la page admin dans `index.html`

Cette étape est manuelle et dépend de l'architecture de votre `index.html` (26 100 lignes).

#### A) Insérer le markup HTML

Ouvrir `06_BLOC_E_admin_monitoring/admin-rituels.html`, copier les **3 blocs** :

1. `<section id="page-admin-rituels">...` → coller au même niveau que vos autres `<section id="page-admin-*">`
2. `<div id="dispatch-detail-drawer">...` → coller à la fin du `<body>`
3. `<div id="dryrun-modal">...` → coller à la fin du `<body>`

#### B) Fusionner le CSS

Ouvrir `admin-rituels.css` et coller le contenu dans votre `<style>` principal.

**Conflits possibles** à vérifier :
- `.btn`, `.btn--primary`, `.btn--secondary` : déjà chez vous ? À fusionner
- `.eyebrow` : déjà défini ? À mutualiser
- `.form-input`, `.form-select`, `.form-label` : pareil
- `.kpi-card` : déjà utilisée sur votre dashboard admin ? À fusionner

#### C) Charger le JavaScript

Coller `admin-rituels.js` dans une balise `<script>` à la fin de `<body>`, ou dans votre fichier JS principal.

**Prérequis dans votre code existant** — avant le chargement du script, exposer :

```javascript
window.OXV = {
  supabase: supabaseClient,  // votre instance Supabase JS déjà initialisée
  isAdmin: true,             // résultat de votre check is_admin()
  showPage: showPage,        // votre fonction de routing single-page
};
```

#### D) Brancher le routing

```javascript
function navigateToAdminRituels() {
  if (!window.OXV.isAdmin) return;
  document.querySelectorAll('.page').forEach(p => p.hidden = true);
  document.getElementById('page-admin-rituels').hidden = false;
  window.OXV.showAdminRituels();
}
```

#### E) Ajouter le lien de navigation admin

Dans votre menu admin (sidebar ou top nav) :

```html
<a href="#admin-rituels" class="admin-nav__link" onclick="navigateToAdminRituels()">
  <span class="admin-nav__icon">✉</span>
  Rituels
</a>
```

---

### ☐ Étape 21 — Tests end-to-end en conditions réelles

Le moment de vérité.

#### Test 1 : Dry run depuis la page admin

1. Naviguer vers la page admin Rituels
2. Cliquer **"Envoi test"**
3. Sélectionner **J-7**, mettre votre email
4. **Envoyer** → email reçu en quelques secondes
5. Refaire avec **J-2** (attention : coût ~0,16 € car ça déclenche OpenAI + Eleven Labs)
6. Refaire avec **J-1** (météo réelle La Génétouze)

#### Test 2 : Cycle réel sur une fausse inscription

```sql
-- 1) Trouver votre propre user_id
SELECT id FROM users WHERE email = 'votre.email@example.com';

-- 2) Trouver une session dans ~8 jours
SELECT id, session_date FROM sessions
WHERE session_date BETWEEN now()::date + interval '8 days' AND now()::date + interval '10 days'
LIMIT 1;

-- 3) Créer une registration test
INSERT INTO registrations (user_id, session_id, vehicle_id, tier, ref, status)
VALUES ('<USER_ID>', '<SESSION_ID>', '<VEHICLE_ID>', 'access', 'OXV-TEST0001', 'confirmed')
RETURNING id;

-- 4) Planifier les rituels
SELECT public.schedule_rituals_for_registration('<NEW_REGISTRATION_ID>');

-- 5) Forcer scheduled_for à maintenant pour test immédiat (sinon attendre J-7)
UPDATE ritual_dispatches
SET scheduled_for = now() - interval '1 minute'
WHERE registration_id = '<NEW_REGISTRATION_ID>'
  AND ritual_type = 'jminus7';
```

```bash
# 6) Déclencher manuellement
curl -X POST \
  https://fouvuqkdxarjpjbqnsjq.supabase.co/functions/v1/ritual_dispatcher \
  -H "Authorization: Bearer <SERVICE_ROLE_KEY>"
```

7. **Vérifier dans la page admin** : la ligne apparaît, statut `sent`, vous recevez l'email
8. **Ouvrir l'email** → attendre 1-2 min → le tracking apparaît (Livré ✓, Ouvert ✓)

#### Test 3 : Webhook Resend en conditions réelles

- Ouvrir un des emails test
- Cliquer sur la playlist (J-7) ou sur le bouton play (J-2)
- Attendre 1-2 min
- Recharger la page admin
- **Engagement** doit afficher Ouvert ✓ et Cliqué ✓

#### Test 4 : Relance d'un dispatch failed

```sql
UPDATE ritual_dispatches SET status = 'failed', last_error = 'test' WHERE id = '<UUID>';
```

- Recharger la page → la ligne apparaît avec bouton **"Relancer"**
- Cliquer **"Relancer"** → confirmer → la ligne repasse en `pending`
- Attendre le prochain cycle pg_cron OU curl manuel
- Le dispatch passe en `sent`

#### Test 5 : Export CSV

- Cliquer **"Export CSV"** → un fichier `oxv_rituels_2026-XX-XX.csv` se télécharge
- Ouvrir dans Excel ou Numbers → vérifier les colonnes (ID, Rituel, Statut, Pilote, Email, etc.)

---

## ✅ Une fois les 21 étapes complétées

Votre système est **opérationnel en production**.

Désormais, **pour chaque nouvelle inscription confirmée** (registration passée en statut `confirmed` par l'admin), il suffira d'appeler :

```sql
SELECT public.schedule_rituals_for_registration('<REGISTRATION_ID>');
```

Et les 3 rituels J-7, J-2, J-1 s'enverront automatiquement aux dates calculées, sans intervention.

**Idéalement, vous brancherez cette fonction dans votre workflow admin existant** : à l'endroit du code où vous passez une registration en `confirmed` (validation paiement, par exemple), ajouter un appel à `schedule_rituals_for_registration`.

---

## 📊 Récapitulatif coûts annuels

Sur la base de **640 audios/an** (32 sessions × 20 pilotes max) :

| Poste | Coût annuel |
|---|---|
| OpenAI GPT-4o | ~5 € |
| Eleven Labs Creator | 264 € |
| Resend | 0 € |
| Supabase Storage + Functions | 0 € |
| Open-Meteo | 0 € |
| **TOTAL** | **~270 € / an** |

Soit **0,42 € par pilote-session** = 0,17% d'un Access à 250 € TTC.

---

## 🆘 En cas de problème

**La function ne se déclenche pas**
- `SELECT * FROM cron.job WHERE jobname = 'ritual_dispatcher_hourly';` → vérifier que le cron existe
- Logs : `supabase functions logs ritual_dispatcher --tail`

**Un dispatch reste en `generating`**
- Le timeout 60 s a été atteint (probablement audio J-2). Solution : remettre manuellement en `pending` puis relancer.
- ```sql
  UPDATE ritual_dispatches SET status = 'pending', attempt_count = 0 WHERE status = 'generating' AND last_attempt_at < now() - interval '5 minutes';
  ```

**Pas de tracking d'ouverture (delivered_at NULL)**
- Vérifier que le webhook Resend est bien configuré et le secret correct
- Vérifier dans `resend_events` que les events arrivent bien

**Erreur "Forbidden" sur `admin_ritual_stats`**
- La fonction `is_admin()` n'existe pas dans votre projet, ou retourne false pour votre user. À adapter selon votre logique.

**L'audio J-2 sonne mal**
- Ajuster `stability` dans `lib/elevenlabs.ts` (0.40 plus expressif / 0.70 plus monocorde)
- Changer la voix (mettre à jour `ELEVENLABS_VOICE_ID` dans les secrets)

---

## 📚 Documents de référence

À garder dans votre repo OXV sous `/docs/rituels/` :

- `01_GUIDE/GUIDE_MAITRE.md` (ce fichier)
- `02_BLOC_A_database/migration_rituals.sql`
- `03_BLOC_B_prompt_voix/ritual_audio_prompt.ts`
- `04_BLOC_C_templates_emails/` (3 fichiers HTML)
- `05_BLOC_D_edge_function_dispatcher/README_BLOC_D.md`
- `06_BLOC_E_admin_monitoring/README_BLOC_E.md`

---

*Système OXV — Rituels pré-session J-7, J-2, J-1*
*Conception et livraison : 21-22 mai 2026*
*Statut : prêt au déploiement, en attente d'activation*
