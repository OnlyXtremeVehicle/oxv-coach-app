# 📦 OXV — Livrable complet : Système de rituels pré-session

> **Tout ce qui a été produit dans notre session de travail (21-22 mai 2026).**
> Conception, code, templates, documentation — prêt au déploiement.

---

## 🗂️ Que contient ce livrable ?

Un système complet qui envoie automatiquement trois messages à chaque pilote OXV avant sa session :

- **J-7** — Email de confirmation avec playlist Spotify de saison
- **J-2** — Audio personnalisé généré par IA (voix Eleven Labs)
- **J-1** — Email de rappel avec météo réelle La Génétouze

Plus une page admin de monitoring complète, un tracking d'engagement, et un bouton "Envoi test" pour valider avant chaque déploiement.

---

## 🚀 Par où commencer ?

**Lisez d'abord** : [`01_GUIDE/GUIDE_MAITRE.md`](./01_GUIDE/GUIDE_MAITRE.md)

C'est le document principal. Il vous guide en **21 étapes ordonnées** depuis la création des comptes API jusqu'aux tests end-to-end finaux. Comptez 10h de travail réparties sur 3-5 jours.

---

## 📁 Arborescence

```
OXV_RITUELS_COMPLET/
│
├── README.md ............................ (ce fichier — sommaire visuel)
│
├── 01_GUIDE/
│   └── GUIDE_MAITRE.md .................. 🎯 Document maître, à lire en premier
│                                            21 étapes de A à E, chronologie 5 jours,
│                                            checklist complète
│
├── 02_BLOC_A_database/
│   └── migration_rituals.sql ............ Migration Supabase initiale
│                                            (table ritual_dispatches, RLS,
│                                            pg_cron, bucket Storage, fonctions)
│
├── 03_BLOC_B_prompt_voix/
│   └── ritual_audio_prompt.ts ........... System prompt GPT-4o (les 10 règles)
│                                            + builder user prompt
│                                            + fonction d'appel OpenAI
│                                            + paramètres Eleven Labs
│
├── 04_BLOC_C_templates_emails/
│   ├── email_jminus7.html ............... Template HTML email J-7
│   ├── email_jminus2.html ............... Template HTML email J-2 (enveloppe audio)
│   └── email_jminus1.html ............... Template HTML email J-1 (météo)
│
├── 05_BLOC_D_edge_function_dispatcher/
│   ├── README_BLOC_D.md ................. Guide de déploiement
│   └── supabase/functions/ritual_dispatcher/
│       ├── index.ts ..................... Orchestrateur HTTP appelé par pg_cron
│       ├── handlers/
│       │   ├── jminus7.ts ............... Logique du rituel J-7
│       │   ├── jminus2.ts ............... Logique du rituel J-2 (le plus complexe)
│       │   └── jminus1.ts ............... Logique du rituel J-1
│       └── lib/
│           ├── supabase.ts .............. Client DB + Storage + helpers
│           ├── openai.ts ................ Appel GPT-4o
│           ├── prompt.ts ................ System prompt importable
│           ├── elevenlabs.ts ............ TTS Eleven Labs
│           ├── resend.ts ................ Envoi emails + templating
│           ├── weather.ts ............... Open-Meteo + mapping FR
│           └── templates.ts ............. 3 HTML embarqués + helpers dates
│
├── 06_BLOC_E_admin_monitoring/
│   ├── README_BLOC_E.md ................. Guide d'intégration
│   ├── migration_rituals_bloc_e.sql ..... Migration complémentaire
│   │                                       (tracking, stats, resend_events)
│   ├── admin-rituels.html ............... Markup HTML page admin
│   ├── admin-rituels.css ................ Styles
│   ├── admin-rituels.js ................. Logique JavaScript
│   └── supabase/functions/
│       ├── resend_webhook/index.ts ...... Webhook tracking ouvertures/clics
│       └── ritual_dryrun/index.ts ....... Envois test sans toucher DB
│
└── 99_ASSETS/
    └── insigne_OXV_reference.png ........ Insigne OXV à optimiser pour emails
                                            (extrait de votre favicon V8.2)
```

---

## 📊 État global

| Bloc | Fonction | Statut | Fichiers |
|---|---|:---:|:---:|
| **A** | Schéma Supabase | ✅ Prêt | 1 |
| **B** | Prompt GPT-4o + Voix Eleven Labs | ✅ Prêt | 1 |
| **C** | Templates Resend HTML | ✅ Prêt | 3 |
| **D** | Edge Function `ritual_dispatcher` | ✅ Prêt | 10 |
| **E** | Page admin + Webhook + Dryrun | ✅ Prêt | 7 |
| **Guide** | Chronologie de mise en place | ✅ Prêt | 1 |
| **Assets** | Insigne référence | ✅ Prêt | 1 |
| | | | **24 fichiers** |

---

## 💰 Coûts annuels

| Poste | Coût |
|---|---|
| OpenAI GPT-4o (génération scripts) | ~5 €/an |
| Eleven Labs Creator (TTS) | 264 €/an |
| Resend (emails) | 0 € |
| Supabase Storage + Edge Functions | 0 € |
| Open-Meteo (API météo) | 0 € |
| **TOTAL** | **~270 €/an** |

Soit **0,42 € par pilote-session** sur la base de 640 audios/an.

---

## 🎯 Promesse fonctionnelle

Une fois déployé, le système :

1. **Détecte** chaque nouvelle inscription confirmée (registration → `confirmed`)
2. **Planifie** automatiquement 3 dispatches (J-7, J-2, J-1) via un seul appel SQL
3. **Déclenche** pg_cron toutes les heures de 17h à 21h (heure Paris)
4. **Génère** pour le J-2 un script personnalisé via GPT-4o, puis un MP3 via Eleven Labs
5. **Récupère** la météo réelle La Génétouze via Open-Meteo pour le J-1
6. **Envoie** les 3 emails via Resend avec templates HTML responsive
7. **Track** les ouvertures et clics via webhook Resend
8. **Permet** au pilote de désactiver chaque rituel indépendamment depuis ses préférences
9. **Permet** à l'admin de monitorer, relancer, exporter, et envoyer des tests

Tout cela **sans aucune intervention humaine** une fois activé.

---

## 🆘 Support

Si vous rencontrez un blocage à une étape précise du guide maître :

1. Vérifier la section **"En cas de problème"** à la fin du guide
2. Lire le `README_BLOC_D.md` ou `README_BLOC_E.md` selon la zone concernée
3. Reprendre une conversation avec moi en mentionnant l'étape exacte et le message d'erreur

---

## 📜 Historique

- **21 mai 2026** : Conception des 3 rituels, validation du contenu, choix des décisions structurantes
- **21-22 mai 2026** : Production des Blocs A, B, C, D, E (24 fichiers livrés)

---

*Bon déploiement.*
