# OXV Mirror — brief de dépôt

*À placer à la racine de `oxv-app`. Lu au début de chaque session de Claude Code.*
*Version du 30/08/2026, après lecture du dépôt et de la base de production.*

---

## Ce qu'est ce produit, en trois phrases

OXV Mirror enregistre ce qu'un pilote fait en piste, à 25 Hz, et le lui montre.
Il ne conseille pas, il ne classe pas, il n'explique pas. **Il montre.**

Cette retenue n'est pas une modestie de façade : OXV n'est pas agréé pour
l'enseignement du pilotage, et c'est elle qui autorise l'outil à entrer dans la
cabine d'un professionnel sans entrer dans le champ du coaching sportif.

---

## LA RÈGLE DE TRAVAIL NUMÉRO UN

**Avant d'écrire une fonction, cherchez si elle existe déjà.**

Cinq manques ont été signalés dans ce dossier par une lecture faite sans le
dépôt. **Les cinq existaient** : le rééchantillonnage en distance, la projection
curviligne, le chemin d'ingestion `.ubx`, le lien public révocable, et la garde
contre les moteurs de démonstration. Environ dix-huit jours de plan se sont
évaporés à la lecture.

Trois endroits à consulter avant toute écriture :

1. **`src/__tests__/modulesOrphelins.guard.test.ts`** — quarante modules écrits,
   testés et **dormants**, chacun avec sa raison et sa condition de sortie. Si
   ce que vous alliez écrire y figure, il ne reste qu'à le brancher.
2. **`src/features/presentations/registrePresentations.ts`** — les 65 fiches, et
   `compositionLogic.ts` qui décide de ce qui s'ouvre.
3. **La liste des migrations et des fonctions edge** — 34 fonctions actives.

**Ne nommez jamais un défaut sans citer sa garde.** Si vous ne trouvez pas la
garde, cherchez encore avant d'affirmer qu'elle manque.

---

## Les interdits — ils ne se négocient pas ligne par ligne

**Jamais de conseil.** Aucun texte, aucune étiquette, aucune notification ne dit
au pilote quoi faire. Lexique proscrit : *devrait, il faut, essayez, améliorez,
optimisez, corrigez*. Le filtre existe : `src/services/aiSafetyFilter.ts`,
52 termes. On l'étend, on ne le double pas.

**Jamais de causalité.** On pose les faits côte à côte, on ne les relie pas.
Proscrit : *parce que, donc, grâce à, à cause de, ce qui explique, la raison
est*. Cela vaut pour le visuel : ni trait, ni flèche, ni couleur partagée entre
une note et un tour.

**Jamais de classement entre pilotes.** Un pilote se compare à lui-même et au
plateau officiel de l'épreuve — jamais à un autre pilote nommé, teammate
compris. Les murs publics n'affichent ni chrono, ni classement, ni donnée de
plateau.

**Jamais de nom sur une surface publique.** Numéros de course et pseudonymes.
La table `plateau` ne contient aucun nom de tiers.

**Jamais un chiffre qui ne vient pas de la base.** Un modèle de langage écrit une
requête ; il ne produit pas de valeur.

**Jamais de phrase sur une feuille de données.** Voir la règle des mots-clés
ci-dessous.

**Jamais un écran blanc.** Cinq états obligatoires ; l'état vide nomme le champ
manquant.

**Jamais de biométrie hors du canal coach.** `liveHealthGate.ts` est
fail-closed, liste blanche stricte. Données de santé au sens de l'article 9.

**Jamais dormir sans le dire.** Brancher, ou inscrire dans la liste des
orphelins avec la raison et la condition de sortie. Un drapeau sans déclencheur
nommé ni date est du code mort déguisé.

---

## La règle des mots-clés

**Toute feuille de données ne montre que des mots-clés, jamais de phrase.**

Une chaîne est une phrase si elle compte **plus de trois mots ET** contient un
mot outil : `le la les un une des du de` · `vous votre vos` ·
`est sont a ont était sera` · `dans avec pour que qui sur sans` ·
`plus moins ce cette`.

Quatre règles d'écriture d'un mot-clé : majuscules, forme `SUJET` ou
`SUJET · PRÉCISION`, jamais de verbe conjugué ; trois mots au plus de chaque
côté du point médian ; il résume le sujet, il ne paraphrase pas ;
**aucun mot outil, jamais** — les mots-clés se composent, et deux fragments
licites peuvent produire une chaîne qui ne l'est plus.

**Les feuilles de récit** — le débrief rédigé, la phrase du coach, les notes du
pilote — gardent la prose, sous le filtre existant. Le manifeste des deux
familles vit dans `src/lib/surfacesRestitution.ts` ; une surface absente des
deux est elle-même une violation.

---

## La règle de taille — mesurée, pas choisie

`ISO 9241-303` fixe la hauteur de capitale en minutes d'arc : plancher **16′**,
cible **20 à 22′**. À **600 mm** — bras tendu, debout au camion — sur une tablette
à 264 ppi :

**Rien sous 21 pt. Tout ce qui doit être lu de façon fiable à 29 pt.**

La maquette de console actuelle porte ses mots-clés à 7,3′-12,3′, soit la moitié
du plancher, pendant que ses nombres sont à 28-45′. **Elle rend les nombres
lisibles et le sens illisible** — or la règle des mots-clés fait des mots-clés le
contenu.

Conséquence à ne pas contourner : **on ne peut pas seulement grossir, il faut
couper.** Voir `design/72_lisibilite.html` — la même feuille passe de trente-quatre
valeurs à douze. La contrainte de taille est une contrainte éditoriale déguisée.

**Le fond sombre reste** : en forte lumière ambiante l'effet de polarité disparaît
(Dobres 2017). Il se paie en taille, pas en couleur. Et sur fond sombre, un texte
clair paraît plus gras — la correction est l'axe **`GRAD`** d'une fonte variable,
jamais une baisse de `font-weight`, qui décalerait les chasses.

---

## Le ton, dans tout ce qui s'affiche

Minimalisme sec. Vouvoiement. Aucun emoji, aucune exclamation, aucun
encouragement, aucune félicitation.

Vocabulaire de télémétrie **figé** : Cap, Trajectoire, Anticipation, Visée,
Plongée. Pas de renommage avant données réelles.

**Ne dites jamais « tour idéal ».** Le catalogue a tranché le 26/08 : la lecture
s'appelle **« Potentiel démontré »**, et sa méthode dit *« Aucune continuité
vérifiée aux jonctions entre morceaux : jamais un tour garanti. »* La garde
`idealLapNonBranche` échoue le jour où `idealLapTime` est câblé à un écran.

L'assistant s'appelle « Questionner ses données ». Pas de nom propre, pas de
personnalité, pas de voix. Le faucon est un totem interne : jamais dans un
contenu client, sous aucun nom.

---

## Les sept règles de structure

| # | Règle | Garde |
|---|---|---|
| R1 | Tout écran a **deux** entrées. Exceptions listées, justifiées, datées | `deuxEntrees` |
| R2 | Aucun orphelin **neuf**, et aucune entrée périmée dans la liste connue | `modulesOrphelins` |
| R3 | Les deux univers visuels ne se mélangent pas ; seule la couche 2 traverse | `frontiereUnivers` |
| R4 | L'assistant ne conseille jamais | `aiSafetyFilter`, étendu |
| R5 | Toute requête de trajectoire trie sur `elapsed_ms`, jamais `created_at` | `triElapsedMs` |
| R6 | Tout écran de donnée monte les cinq états et nomme le champ attendu | `cinqEtats` |
| R7 | Aucun mur public ne porte de classement ni de donnée de plateau | `murSansClassement`, `plateauNonPublic` |
| R8 | Aucune phrase sur une feuille de données | `check-doctrine`, 2ᵉ passe |

**Une garde rouge arrête le travail.** On ne la contourne pas, on ne la
commente pas, on ne l'ajoute pas à une liste d'exclusions. Si elle gêne, c'est
la conception qu'on rediscute.

**R2 a une subtilité** : la garde exige `mesures.length > 0`, pour qu'un
résolveur cassé ne rende pas la liste artificiellement verte. « Zéro orphelin »
n'est donc pas un objectif atteignable ni souhaitable. Le bon geste est : un
module branché **sort de `CONNUS` dans le même commit**.

---

## L'état réel, mesuré le 30/08/2026

**Ce qui tourne.** Une capture réelle existe : séance
`ff384ace-d6ce-414b-8338-cef030218ee0`, Bouteville, 12/08/2026 — **26 999 trames
à 25,0 Hz exactement**, trois tours (360,485 / **327,542** / 339,483 s) de
5 875 / 5 874 / 5 875 m, 100 % de fixes valides, 15,4 satellites, 0,23 m de
précision, gyroscope et trois G sur chaque trame.

**C'est la séance de référence.** Toute vérification d'écran se fait sur elle.
Réserve : c'est une boucle **routière**, roulée de nuit, avec deux arrêts à 7,8
et 12,2 km/h. Elle valide la chaîne ; elle ne calibre pas un seuil de piste.

**Ce qui ne tourne pas.**

- `heading` est **nul sur 100 % des trames**. Le parseur est juste — vérifié
  offset par offset contre le protocole RaceBox rev 8 — c'est le boîtier qui
  laisse le bit 5 des *Fix Status Flags* à zéro. **N'affichez aucune
  orientation.**
- `heading_accuracy`, `speed_accuracy`, `pdop` : trois colonnes créées par
  migration et **jamais écrites**. Ce sont elles qui rendraient la question du
  cap décidable.
- QDI sur la vraie séance : `fluidité 0`, `accélération 0`, `freinage 7`.
  Les branches inertielles dérivent un signal **brut** : jerk latéral de médiane
  0,286 g/s mais de moyenne 2,240 (p95 14,0). Lissé sur 13 trames, la moyenne
  tombe à 0,629 → fluidité 78. **Ne touchez pas aux seuils sans décision
  explicite du fondateur** : c'est un incrément de `QDI_ALGO_VERSION` et un
  recalcul de l'historique.
- `session_insights` ne contient qu'une ligne, `mirror-insights-demo`, sur une
  séance à zéro trame. **L'application la filtre trois fois** — rien à coder.
- `cycle_steps` et `coach_annotations` : **zéro ligne**. Les fiches P36 et
  P46–P51 resteront écartées.
- Bouteville n'a **aucun virage détecté** (`corners` nul) alors qu'il porte 139
  points de tracé médian.
- L'intention du 12/08 existe dans `session_intentions` mais son `session_id`
  est **nul** : rattachée au circuit, pas à la séance. P01 est écartée pour rien.

---

## Ce qui existe déjà et qu'il ne faut pas réécrire

| Besoin | Ce qui le porte |
|---|---|
| Rééchantillonnage en distance | `src/telemetry/resample.ts` |
| Projection curviligne | `src/telemetry/projectionCurviligne.ts` |
| Lien public révocable | `app_progression_shares` + 3 fonctions `SECURITY DEFINER` |
| Filtre doctrinal de sortie | `src/services/aiSafetyFilter.ts` |
| Débrief déterministe | `src/services/debriefGenerator.ts` |
| Détection de virages | `detect-circuit-corners` + `circuitGenerator.ts` |
| Choix de la lecture à ouvrir | `compositionLogic` + `registrePresentations` |
| Sources du moteur | `sourcesCompositionService` + `pilot_presentation_*` |
| Garde des moteurs de démo | `MOTEURS_INSIGHTS_REELS` + `insightsMesures` |
| Santé de la liaison | `onCaptureLinkStatus`, `getCaptureLinkStatus` |
| Récupération OSM | `fetchOsmWay` dans `circuitGenerator.ts` |

---

## Comment travailler ici

**Branche.** `migration/sdk-55`. `main` protégée, intégration continue verte
avant fusion.

**Les spécifications.** `docs/specs/A_Terrain.md` à `G_MotsCles.md`. Chaque
interface y donne sa route, ses deux appelants, ses données, ses cinq états, ses
interdits, ses critères d'acceptation et sa garde.

**Quand la spécification se trompe.** Les blocs C et F ont été corrigés le 30/08
après lecture. Les autres peuvent porter des erreurs du même genre. Vérifier
dans le code, **corriger la spécification**, et le dire. Une spécification fausse
qu'on suit est pire qu'une spécification absente.

**Mesurer avant de croire.** Toute affirmation de plus de deux semaines se
remesure. Le registre de disposition compte 697 lignes.

**Un écran = un objet.** Pas de composant qui sert deux écrans en changeant de
forme. La couche 2 est la seule exception, et elle est explicite.

---

## Le calendrier

| Date | Ce qui doit être vrai |
|---|---|
| 02/09 | Pièces de la passerelle commandées ; courriers ITS et FFSA partis |
| 05/09 | Circuit du Bugatti en base, virages détectés |
| 08/09 | Chemin d'ingestion unique |
| 12/09 | Coach ouvert au multi-circuit ; secteurs officiels ; cinq états |
| 15/09 | Passerelle assemblée, deux heures de route sans perte |
| **19/09** | **Répétition de Bouteville. Point de non-retour du matériel** |
| 20/09 | Pass équipe obtenu par écrit |
| 26-27/09 | Le Mans — 24 Heures Camions, devant une écurie professionnelle |
| 10-11/10 | Albi — finale du championnat |

**Ce qui n'est pas prouvé le 19 septembre ne part pas au Mans.** Une
fonctionnalité à moitié faite qui s'ouvre devant un pilote professionnel coûte
plus cher que son absence.

**Ordre de sacrifice.** Tiennent en dernier : les circuits en base, le chemin
d'ingestion, la passerelle, la répétition. Tombent en premier : le référentiel
plateau (il se relève à la main sur la feuille officielle), la page J+1, les
secteurs officiels, l'ouverture du coach.

---

## Décisions prises, à ne pas rouvrir

| Sujet | Décision | Date |
|---|---|---|
| Mots-clés | Champ `court` obligatoire ; la phrase reste au second geste | 30/08 |
| Débrief rédigé | Reste une feuille de récit, prose sous filtre | 30/08 |
| Tour idéal | Vocabulaire rétrogradé en « Potentiel démontré » | 26/08 |
| Lecture plateau ITS | Automatisée dès Le Mans, avec ses garde-fous | 30/08 |
| Compte écurie | Voit tout par défaut — **pas avant Le Mans** | 30/08 |
| Taille de texte | Plancher 21 pt, cible 29 pt à 600 mm | 30/08 |
| Fond sombre | Conservé, payé en taille | 30/08 |

## Décisions en attente, à ne pas contourner

| Sujet | Ce qu'il bloque | Butée |
|---|---|---|
| Filtrage du signal inertiel (QDI) | Deux branches à zéro devant un professionnel | 19/09 |
| Débrief IA : opt-out ou opt-in | Le comportement par défaut au Mans | 25/09 |
| Identifiants OSM du Bugatti et d'Albi | Les deux circuits en base | 05/09 |
| Choix de la fonte (critères dans `design/71`) | Fige 178 écrans | 12/09 |

Ne pas contourner une décision manquante par une hypothèse. La signaler et
attendre.
